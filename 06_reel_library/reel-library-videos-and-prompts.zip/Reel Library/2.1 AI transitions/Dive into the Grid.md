# Dive into the Grid

Section: 2.1 AI transitions
Video: Dive into the Grid.mp4 (4 seconds, no sound)

## What it does
A wall of tiles (stills of your clip and coloured cards), the camera dives into the middle tile, which is your live video.

## Best used when
Choosing one out of many (one tool, one idea)

## Prompt to make it from scratch
A transition made with code (Remotion) for a talking-head reel: a wall of tiles (stills of your clip and coloured cards), the camera dives into the middle tile, which is your live video. About 0.6 to 1 s, lands exactly on the cut, keeps your footage colours unchanged; words and font adapted to the video.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
