# Swipe

Section: 2.1 AI transitions
Video: Swipe.mp4 (4 seconds, no sound)

## What it does
A full-screen swipe of colour panels wipes across your shot and reveals the next part

## Best used when
Moving quickly between parts of a list

## Prompt to make it from scratch
A transition made with code (Remotion) for a talking-head reel: A full-screen swipe of colour panels wipes across your shot and reveals the next part. About 0.6 to 1 s, lands exactly on the cut, keeps your footage colours unchanged; words and font adapted to the video.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
