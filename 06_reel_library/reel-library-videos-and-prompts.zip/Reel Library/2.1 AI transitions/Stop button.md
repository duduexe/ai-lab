# Stop button

Section: 2.1 AI transitions
Video: Stop button.mp4 (4 seconds, no sound)

## What it does
The picture closes like a window to a STOP button with an arrow. The words, font and colours can be changed to match the video

## Best used when
Ending a step, a tool or the video, techy tone

## Prompt to make it from scratch
A transition made with code (Remotion) for a talking-head reel: The picture closes like a window to a STOP button with an arrow. The words, font and colours can be changed to match the video. About 0.6 to 1 s, lands exactly on the cut, keeps your footage colours unchanged; words and font adapted to the video.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
