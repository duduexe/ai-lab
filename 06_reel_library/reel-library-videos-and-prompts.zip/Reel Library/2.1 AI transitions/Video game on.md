# Video game on

Section: 2.1 AI transitions
Video: Video game on.mp4 (4 seconds, no sound)

## What it does
Blinking PRESS START on black, then the picture comes in big square pixels. The words, font and colours can be changed to match the video

## Best used when
Starting a challenge, a level or a game-like series

## Prompt to make it from scratch
A transition made with code (Remotion) for a talking-head reel: Blinking PRESS START on black, then the picture comes in big square pixels. The words, font and colours can be changed to match the video. About 0.6 to 1 s, lands exactly on the cut, keeps your footage colours unchanged; words and font adapted to the video.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
