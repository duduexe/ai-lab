# Tile Tunnel Fly-in

Section: 2.1 AI transitions
Video: Tile Tunnel Fly-in.mp4 (4 seconds, no sound)

## What it does
A 3D corridor of white tiles with coloured lines; the camera flies down it to your video.

## Best used when
A dramatic intro or a new section

## Prompt to make it from scratch
A transition made with code (Remotion) for a talking-head reel: a 3D corridor of white tiles with coloured lines; the camera flies down it to your video. About 0.6 to 1 s, lands exactly on the cut, keeps your footage colours unchanged; words and font adapted to the video.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
