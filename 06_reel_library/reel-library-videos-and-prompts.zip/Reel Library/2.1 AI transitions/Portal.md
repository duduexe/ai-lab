# Portal

Section: 2.1 AI transitions
Video: Portal.mp4 (4 seconds, no sound)

## What it does
A bright and white glowing ring opens with spinning coloured spirals; you are seen through it; then the ring widens until you fill the screen.

## Best used when
Entering a new world, tool or chapter

## Prompt to make it from scratch
A transition made with code (Remotion) for a talking-head reel: a bright and white glowing ring opens with spinning coloured spirals; you are seen through it; then the ring widens until you fill the screen. About 0.6 to 1 s, lands exactly on the cut, keeps your footage colours unchanged; words and font adapted to the video.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
