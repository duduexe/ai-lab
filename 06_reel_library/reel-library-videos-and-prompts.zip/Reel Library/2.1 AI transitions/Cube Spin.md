# Cube Spin

Section: 2.1 AI transitions
Video: Cube Spin.mp4 (4 seconds, no sound)

## What it does
The shot turns like a cube to show the next shot on its side. Option: exactly on a cut between two clips, both clips stay in time with your voice

## Best used when
Moving to a new part of the video with energy

## Prompt to make it from scratch
A transition made with code (Remotion) for a talking-head reel: the shot turns like a cube to show the next shot on its side. About 0.6 to 1 s, lands exactly on the cut, keeps your footage colours unchanged; words and font adapted to the video. Option: exactly on a cut between two clips, both clips stay in time with your voice.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
