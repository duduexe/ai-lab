# Scrunch Intro

Section: 2.1 AI transitions
Video: Scrunch Intro.mp4 (4 seconds, no sound)

## What it does
Your shot starts scrunched into a paper ball on the coloured stage, bounces in, then unfolds with a spring to full screen while the creases fade

## Best used when
The very first second, a playful opening

## Prompt to make it from scratch
A transition made with code (Remotion) for a talking-head reel: Your shot starts scrunched into a paper ball on the coloured stage, bounces in, then unfolds with a spring to full screen while the creases fade. About 0.6 to 1 s, lands exactly on the cut, keeps your footage colours unchanged; words and font adapted to the video.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
