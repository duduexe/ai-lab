# Zoom-Through

Section: 2.1 AI transitions
Video: Zoom-Through.mp4 (4 seconds, no sound)

## What it does
The camera rushes into your face and comes out in the next shot

## Best used when
Going "into" a topic or a screen

## Prompt to make it from scratch
A transition made with code (Remotion) for a talking-head reel: The camera rushes into your face and comes out in the next shot. About 0.6 to 1 s, lands exactly on the cut, keeps your footage colours unchanged; words and font adapted to the video.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
