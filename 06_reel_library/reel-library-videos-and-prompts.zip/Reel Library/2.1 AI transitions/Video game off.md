# Video game off

Section: 2.1 AI transitions
Video: Video game off.mp4 (4 seconds, no sound)

## What it does
The picture leaves in big square pixels, then blinking GAME OVER on black. The words, font and colours can be changed to match the video

## Best used when
A funny fail or "game over" ending

## Prompt to make it from scratch
A transition made with code (Remotion) for a talking-head reel: The picture leaves in big square pixels, then blinking GAME OVER on black. The words, font and colours can be changed to match the video. About 0.6 to 1 s, lands exactly on the cut, keeps your footage colours unchanged; words and font adapted to the video.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
