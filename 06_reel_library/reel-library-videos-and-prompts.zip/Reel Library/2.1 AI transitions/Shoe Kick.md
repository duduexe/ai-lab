# Shoe Kick

Section: 2.1 AI transitions
Video: Shoe Kick.mp4 (4 seconds, no sound)

## What it does
A cartoon bright sneaker swings in from the bottom left and kicks the shot away: it spins off to the top right and the next shot is underneath (nextSrc, or the same clip later), with a burst

## Best used when
A funny "out with the old" or getting rid of something

## Prompt to make it from scratch
A transition made with code (Remotion) for a talking-head reel: A cartoon bright sneaker swings in from the bottom left and kicks the shot away: it spins off to the top right and the next shot is underneath (nextSrc, or the same clip later), with a burst. About 0.6 to 1 s, lands exactly on the cut, keeps your footage colours unchanged; words and font adapted to the video.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
