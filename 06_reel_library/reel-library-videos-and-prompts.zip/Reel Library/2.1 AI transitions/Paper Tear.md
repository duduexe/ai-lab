# Paper Tear

Section: 2.1 AI transitions
Video: Paper Tear.mp4 (4 seconds, no sound)

## What it does
The shot tears apart like paper and the next shot is under it

## Best used when
Revealing what is behind or underneath

## Prompt to make it from scratch
A transition made with code (Remotion) for a talking-head reel: The shot tears apart like paper and the next shot is under it. About 0.6 to 1 s, lands exactly on the cut, keeps your footage colours unchanged; words and font adapted to the video.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
