# Shatter

Section: 2.1 AI transitions
Video: Shatter.mp4 (4 seconds, no sound)

## What it does
White cracks appear, then the picture breaks into 48 pieces that fly out and fall, showing the next shot behind.

## Best used when
A big reveal or "this changes everything" moment

## Prompt to make it from scratch
A transition made with code (Remotion) for a talking-head reel: white cracks appear, then the picture breaks into 48 pieces that fly out and fall, showing the next shot behind. About 0.6 to 1 s, lands exactly on the cut, keeps your footage colours unchanged; words and font adapted to the video.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
