# Start button

Section: 2.1 AI transitions
Video: Start button.mp4 (4 seconds, no sound)

## What it does
An arrow presses a START button on a dark screen, then the picture opens like a window. The words, font and colours can be changed to match the video

## Best used when
Starting a tool, a challenge or a step-by-step, techy tone

## Prompt to make it from scratch
A transition made with code (Remotion) for a talking-head reel: An arrow presses a START button on a dark screen, then the picture opens like a window. The words, font and colours can be changed to match the video. About 0.6 to 1 s, lands exactly on the cut, keeps your footage colours unchanged; words and font adapted to the video.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
