# Shrink To Frame

Section: 2.1 AI transitions
Video: Shrink To Frame.mp4 (4 seconds, no sound)

## What it does
The clip plays full screen, then shrinks (or snaps) down into a rounded window with a thin light border on a plain coloured screen; an optional headline rises in above the window line by line

## Best used when
Moving from the hook to the main point, or putting a title above the video

## Prompt to make it from scratch
A transition made with code (Remotion) for a 1080 x 1920 talking-head reel: the footage plays full screen, then shrinks about 0.6 s (or a quick 0.15 s cut-down) into a rounded window (about 780 x 540 px, thin light border) on a plain coloured screen, with the headline appearing above it line by line. Window on the left side, clear of the app buttons; footage colours unchanged and fonts.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
