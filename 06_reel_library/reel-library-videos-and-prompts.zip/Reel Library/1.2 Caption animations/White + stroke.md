# White + stroke

Section: 1.2 Caption animations
Video: White + stroke.mp4 (4 seconds, no sound)

## What it does
One white word at a time with a black outline

## Best used when
Busy or bright footage where coloured captions would not read

## Prompt to make it from scratch
Captions from the word timings of a talking-head reel: One white word at a time with a black outline. Words appear in time with the voice, placed under the chin inside the platform safe zone.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
