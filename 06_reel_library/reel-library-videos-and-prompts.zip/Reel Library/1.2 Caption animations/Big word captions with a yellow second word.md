# Big word captions with a yellow second word

Section: 1.2 Caption animations
Video: Big word captions with a yellow second word.mp4 (4 seconds, no sound)

## What it does
Big word captions where the second word is yellow

## Best used when
Short punchy phrases where the second word is the point

## Prompt to make it from scratch
Captions from the word timings of a talking-head reel: Big word captions where the second word is yellow. Words appear in time with the voice, placed under the chin inside the platform safe zone.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
