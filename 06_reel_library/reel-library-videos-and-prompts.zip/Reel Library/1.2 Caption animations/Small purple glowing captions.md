# Small purple glowing captions

Section: 1.2 Caption animations
Video: Small purple glowing captions.mp4 (4 seconds, no sound)

## What it does
Small purple captions with a glow

## Best used when
Dreamy or night-time looks where big captions would cover the image

## Prompt to make it from scratch
Captions from the word timings of a talking-head reel: Small purple captions with a glow. Words appear in time with the voice, placed under the chin inside the platform safe zone.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
