# White uppercase captions on the split line

Section: 1.2 Caption animations
Video: White uppercase captions on the split line.mp4 (4 seconds, no sound)

## What it does
White uppercase captions on the line between animation and creator

## Best used when
Split screen: animation on top, you below

## Prompt to make it from scratch
Captions from the word timings of a talking-head reel: White uppercase captions on the line between animation and creator. Words appear in time with the voice, placed under the chin inside the platform safe zone.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
