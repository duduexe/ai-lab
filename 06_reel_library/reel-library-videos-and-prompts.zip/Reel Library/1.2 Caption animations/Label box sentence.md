# Label box sentence

Section: 1.2 Caption animations
Video: Label box sentence.mp4 (4 seconds, no sound)

## What it does
A whole line in dark ink inside a rounded pale box

## Best used when
Tutorial steps or quotes that must read on any background

## Prompt to make it from scratch
Captions from the word timings of a talking-head reel: A whole line in dark ink inside a rounded pale box. Words appear in time with the voice, placed under the chin inside the platform safe zone.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
