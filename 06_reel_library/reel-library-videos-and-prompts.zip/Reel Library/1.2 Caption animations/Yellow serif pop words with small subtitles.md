# Yellow serif pop words with small subtitles

Section: 1.2 Caption animations
Video: Yellow serif pop words with small subtitles.mp4 (4 seconds, no sound)

## What it does
Yellow serif pop words, small subtitles with yellow keywords; also big yellow italic serif words with your script shown in yellow highlights

## Best used when
Storytelling with a few key words that pop

## Prompt to make it from scratch
Captions from the word timings of a talking-head reel: Yellow serif pop words, small subtitles with yellow keywords; also big yellow italic serif words with your script shown in yellow highlights. Words appear in time with the voice, placed under the chin inside the platform safe zone.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
