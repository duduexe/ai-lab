Dudu Experiments' Reel Library: videos and prompts

320 building blocks for short vertical videos. One folder per section. Each item has:
- a short video of it (.mp4, 4 seconds, no sound)
- a text file with the same name (.md): what it does, when to use it, and the prompt to make it with Claude

How to use it: give Claude the video as an example together with the prompt in its text file, then add your own text,
timing and colours. library.md has every item in one file, to give Claude the whole library at once.

The site: https://duduexe.github.io/ai-lab/06_reel_library/

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
You may use the previews, prompts and skill to make your own videos, and post the videos you make. You may not sell, copy, republish or share this library or its content (the descriptions, prompts, previews or skill), in full or in part.
Fonts, emoji and credits: LICENCES.md.
