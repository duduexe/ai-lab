# Hand Writing Sign-off

Section: 4.6 Hand-drawn marks and doodles
Video: Hand Writing Sign-off.mp4 (4 seconds, no sound)

## What it does
A drawn hand holding a bright pen comes in and writes the lines one after the other (the ink follows the pen tip, which bobs like real handwriting), underlines the last line with a bright swoosh, a little heart pops and the hand leaves

## Best used when
A signature or sign-off at the end of a reel ("xoxo, your name"), or any short line that should look hand-written live

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any background: a cartoon hand (pale with a dark outline, coloured sleeve) holding a bright pen enters from the right and writes each line in a handwritten script font (first line big and bright, the others light, all with a dark edge), revealed left to right under the pen tip in about 0.8 to 1.1 s per line; it then draws a bright underline swoosh, a small bright heart pops and the hand leaves to the bottom right; everything fades in the last 0.2 s. stays inside the safe zone (away from the app buttons).

## Source
Made by Claude with code for "Reel Library phone", no licence needed

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
