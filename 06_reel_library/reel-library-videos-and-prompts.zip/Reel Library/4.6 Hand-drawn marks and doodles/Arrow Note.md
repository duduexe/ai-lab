# Arrow Note

Section: 4.6 Hand-drawn marks and doodles
Video: Arrow Note.mp4 (4 seconds, no sound)

## What it does
Hand-drawn arrow that draws itself, with a handwritten note at its tail

## Best used when
Pointing at something with a note

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Hand-drawn arrow that draws itself, with a handwritten note at its tail. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
