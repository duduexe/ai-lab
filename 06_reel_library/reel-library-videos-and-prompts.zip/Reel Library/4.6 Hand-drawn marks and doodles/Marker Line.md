# Marker Line

Section: 4.6 Hand-drawn marks and doodles
Video: Marker Line.mp4 (4 seconds, no sound)

## What it does
A bright marker line draws across a word

## Best used when
Underlining a word

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: a bright marker line draws across a word. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
