# Spider Web

Section: 4.6 Hand-drawn marks and doodles
Video: Spider Web.mp4 (4 seconds, no sound)

## What it does
A white web draws itself in the top left corner, then a cute dark spider drops on its thread, bounces and dangles

## Best used when
Something old, dusty or forgotten

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A white web draws itself in the top left corner, then a cute dark spider drops on its thread, bounces and dangles. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
