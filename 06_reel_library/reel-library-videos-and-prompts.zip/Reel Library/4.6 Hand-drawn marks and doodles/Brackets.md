# Brackets

Section: 4.6 Hand-drawn marks and doodles
Video: Brackets.mp4 (4 seconds, no sound)

## What it does
A hand-drawn bright bracket draws itself on one or both sides of a box, like a teacher marking a paragraph; options: left, right or both, curly or square

## Best used when
Grouping a paragraph, a list or part of a screen you are talking about

## Prompt to make it from scratch
A graphic animation for a 1080 x 1920 reel that works over any video: a slightly uneven hand-drawn bright bracket (curly or square, about 11 px thick with a thinner second pass) draws itself on the left, right or both sides of a given box in about 0.55 s. Fades out at the end, inside the safe zone.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
