# Draw Mark

Section: 4.6 Hand-drawn marks and doodles
Video: Draw Mark.mp4 (4 seconds, no sound)

## What it does
A hand-drawn bright tick or circle draws itself. Option: a slightly uneven hand-drawn circle that overshoots its start, or an arrow with a note, as a graphic (callout)

## Best used when
Ticking or circling something

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A hand-drawn bright tick or circle draws itself. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons). Option: a slightly uneven hand-drawn circle that overshoots its start, or an arrow with a note, as a graphic (callout).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
