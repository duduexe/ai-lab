# Clouds Drift

Section: 4.6 Hand-drawn marks and doodles
Video: Clouds Drift.mp4 (4 seconds, no sound)

## What it does
Two drawn clouds drifting

## Best used when
A calm, dreamy or "cloud" topic

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Two drawn clouds drifting. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
