# Thought Bubble

Section: 4.6 Hand-drawn marks and doodles
Video: Thought Bubble.mp4 (4 seconds, no sound)

## What it does
A cloud-shaped thought bubble with three small bubbles rising from your head. Option glass with Vapor Type: a frosted glass bubble grows from three small bubbles, a word forms out of drifting vapor inside it and drifts away (added. Cloud word: 4th label number 1 = no bubble and no small bubbles, the word itself is made of white cloud (puffy lumpy edge, coloured shade underneath, soft dark shadow), forms out of gathering mist, floats, then drifts up into mist (added

## Best used when
What you are thinking

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A cloud-shaped thought bubble with three small bubbles rising from your head. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
