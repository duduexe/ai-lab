# Question Marks

Section: 4.6 Hand-drawn marks and doodles
Video: Question Marks.mp4 (4 seconds, no sound)

## What it does
Five handwritten question marks in bright and coloured pop in one after the other around your head, wiggle and float up. Option: one big handwritten question mark that wiggles

## Best used when
Confusion

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Five handwritten question marks in bright and coloured pop in one after the other around your head, wiggle and float up. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons). Option: one big handwritten question mark that wiggles.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
