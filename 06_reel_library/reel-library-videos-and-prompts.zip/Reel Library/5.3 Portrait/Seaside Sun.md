# Seaside Sun

Section: 5.3 Portrait
Video: Seaside Sun.mp4 (4 seconds, no sound)

## What it does
Rich colours

## Best used when
Sunny outdoor clips

## Prompt to make it from scratch
A colour filter for talking-head footage: rich colours. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
