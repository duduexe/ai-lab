# Warm Living Room

Section: 5.3 Portrait
Video: Warm Living Room.mp4 (4 seconds, no sound)

## What it does
Warm, darker, dark edges

## Best used when
Cosy indoor evening clips

## Prompt to make it from scratch
A colour filter for talking-head footage: warm, darker, dark edges. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
