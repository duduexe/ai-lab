# Blush Bow

Section: 5.3 Portrait
Video: Blush Bow.mp4 (4 seconds, no sound)

## What it does
Faded blacks

## Best used when
Soft, girly or romantic moments

## Prompt to make it from scratch
A colour filter for talking-head footage: faded blacks. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
