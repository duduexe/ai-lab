# Warm lamp

Section: 6. Lights
Video: Warm lamp.mp4 (4 seconds, no sound)

## What it does
One light in #FF9A4D

## Best used when
A cosy evening mood

## Prompt to make it from scratch
Added light over the footage: one light in #FF9A4D. Soft round light that only adds light and never darkens the picture.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
