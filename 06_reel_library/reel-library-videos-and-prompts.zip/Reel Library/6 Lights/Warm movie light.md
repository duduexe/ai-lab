# Warm movie light

Section: 6. Lights
Video: Warm movie light.mp4 (4 seconds, no sound)

## What it does
One light in #FFB070

## Best used when
A warm, cinematic look on your face

## Prompt to make it from scratch
Added light over the footage: one light in #FFB070. Soft round light that only adds light and never darkens the picture.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
