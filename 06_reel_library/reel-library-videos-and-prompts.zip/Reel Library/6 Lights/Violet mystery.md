# Violet mystery

Section: 6. Lights
Video: Violet mystery.mp4 (4 seconds, no sound)

## What it does
One light in #7A5CFF

## Best used when
A mysterious or secret moment

## Prompt to make it from scratch
Added light over the footage: one light in #7A5CFF. Soft round light that only adds light and never darkens the picture.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
