# Berry rim light

Section: 6. Lights
Video: Berry rim light.mp4 (4 seconds, no sound)

## What it does
Two lights in #FF3D6E and #B04DFF

## Best used when
A bold, music-video look

## Prompt to make it from scratch
Added light over the footage: two lights in #FF3D6E and #B04DFF. Soft round light that only adds light and never darkens the picture.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
