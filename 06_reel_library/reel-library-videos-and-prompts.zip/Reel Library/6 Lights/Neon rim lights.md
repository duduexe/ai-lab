# Neon rim lights

Section: 6. Lights
Video: Neon rim lights.mp4 (4 seconds, no sound)

## What it does
Two lights in #FF5AB6 and #3DE0FF

## Best used when
Gaming, tech or night city looks

## Prompt to make it from scratch
Added light over the footage: two lights in #FF5AB6 and #3DE0FF. Soft round light that only adds light and never darkens the picture.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
