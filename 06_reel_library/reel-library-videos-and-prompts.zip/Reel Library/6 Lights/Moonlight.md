# Moonlight

Section: 6. Lights
Video: Moonlight.mp4 (4 seconds, no sound)

## What it does
One light in #9FB8FF

## Best used when
A night-time scene

## Prompt to make it from scratch
Added light over the footage: one light in #9FB8FF. Soft round light that only adds light and never darkens the picture.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
