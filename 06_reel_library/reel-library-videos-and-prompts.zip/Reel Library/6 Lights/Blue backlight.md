# Blue backlight

Section: 6. Lights
Video: Blue backlight.mp4 (4 seconds, no sound)

## What it does
One light in #4D8BFF

## Best used when
A tech or night mood

## Prompt to make it from scratch
Added light over the footage: one light in #4D8BFF. Soft round light that only adds light and never darkens the picture.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
