# Soft face light

Section: 6. Lights
Video: Soft face light.mp4 (4 seconds, no sound)

## What it does
One light in #FFF4E8

## Best used when
Your face looks a little dark

## Prompt to make it from scratch
Added light over the footage: one light in #FFF4E8. Soft round light that only adds light and never darkens the picture.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
