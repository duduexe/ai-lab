# Golden hour

Section: 6. Lights
Video: Golden hour.mp4 (4 seconds, no sound)

## What it does
One light in #FFC46B

## Best used when
A sunset feel

## Prompt to make it from scratch
Added light over the footage: one light in #FFC46B. Soft round light that only adds light and never darkens the picture.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
