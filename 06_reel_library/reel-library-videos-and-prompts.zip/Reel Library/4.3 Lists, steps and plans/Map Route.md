# Map Route

Section: 4.3 Lists, steps and plans
Video: Map Route.mp4 (4 seconds, no sound)

## What it does
A simple drawn map: pins pop in and a dashed bright route travels from pin to pin

## Best used when
A trip, a journey or steps on a map

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A simple drawn map: pins pop in and a dashed bright route travels from pin to pin. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
