# Progress bar with pills

Section: 4.3 Lists, steps and plans
Video: Progress bar with pills.mp4 (4 seconds, no sound)

## What it does
A thin line along the bottom with a dot that moves through the video, and one pill per part above it: the part being talked about fills bright, finished parts turn coloured, coming parts stay dark

## Best used when
A video with clear parts or steps, so viewers see where they are and stay

## Prompt to make it from scratch
A graphic animation that stays for the whole video: a thin light line near the bottom of the safe zone (y about 1430, x 70 to 880) with a bright dot and a bright filled part that move with time, and one rounded pill per part above it; the current pill fills bright with a small bump, done pills coloured, coming pills dark.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
