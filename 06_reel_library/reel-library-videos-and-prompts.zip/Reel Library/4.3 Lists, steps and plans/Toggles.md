# Toggles

Section: 4.3 Lists, steps and plans
Video: Toggles.mp4 (4 seconds, no sound)

## What it does
Switches like in phone settings flip on one after another

## Best used when
Settings, choices or features turned on

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Switches like in phone settings flip on one after another. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
