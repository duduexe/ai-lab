# Jobs to Experts

Section: 4.3 Lists, steps and plans
Video: Jobs to Experts.mp4 (4 seconds, no sound)

## What it does
A coordinator at the top sends three job cards down three lines to three experts

## Best used when
One task split between helpers or agents

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A coordinator at the top sends three job cards down three lines to three experts. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
