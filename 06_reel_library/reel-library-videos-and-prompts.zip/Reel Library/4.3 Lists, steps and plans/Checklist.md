# Checklist

Section: 4.3 Lists, steps and plans
Video: Checklist.mp4 (4 seconds, no sound)

## What it does
Items appear, then get ticked one by one; a crossed-out item gets a line through it.

## Best used when
A list of steps or things to do

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Items appear, then get ticked one by one; a crossed-out item gets a line through it. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
