# Plan Card

Section: 4.3 Lists, steps and plans
Video: Plan Card.mp4 (4 seconds, no sound)

## What it does
A coloured card above your head: "The plan" with a bright marker underline, rows that write in (file kind icon, an arrow that draws itself, the folder it goes to), then bright ticks one by one, the "0 FILES MOVED" chip turns bright "READY" with sparkles

## Best used when
Showing the plan before doing it

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: a coloured card above your head: "The plan" with a bright marker underline, rows that write in (file kind icon, an arrow that draws itself, the folder it goes to), then bright ticks one by one, the "0 FILES MOVED" chip turns bright "READY" with sparkles (text "Videos>Talking heads. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
