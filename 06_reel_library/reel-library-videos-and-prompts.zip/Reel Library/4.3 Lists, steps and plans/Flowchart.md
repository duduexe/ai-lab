# Flowchart

Section: 4.3 Lists, steps and plans
Video: Flowchart.mp4 (4 seconds, no sound)

## What it does
Steps stacked from top to bottom: a box pops in, then an arrow draws down to the next box

## Best used when
Explaining steps in order

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Steps stacked from top to bottom: a box pops in, then an arrow draws down to the next box. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
