# Guide Step Page

Section: 4.3 Lists, steps and plans
Video: Guide Step Page.mp4 (4 seconds, no sound)

## What it does
One full-screen guide step (title or 1 to 6); the title opens with your video shrinking into a window

## Best used when
A full-screen step in a tutorial

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: One full-screen guide step (title or 1 to 6); the title opens with your video shrinking into a window. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
