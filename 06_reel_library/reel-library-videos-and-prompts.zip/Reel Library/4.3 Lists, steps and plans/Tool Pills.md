# Tool Pills

Section: 4.3 Lists, steps and plans
Video: Tool Pills.mp4 (4 seconds, no sound)

## What it does
Rounded labels with the names of the tools you used pop in one by one, with an optional name tag

## Best used when
Listing the tools you used

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Rounded labels with the names of the tools you used pop in one by one, with an optional name tag. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).: pills pop in one by one, optional name tag.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
