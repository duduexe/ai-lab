# Doodle Outline

Section: 3.1 AI effects
Video: Doodle Outline.mp4 (4 seconds, no sound)

## What it does
Chalky light and bright outlines around you that wiggle like hand-drawn animation, with squiggles and circles

## Best used when
A fun, hand-made feel around you

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: Chalky light and bright outlines around you that wiggle like hand-drawn animation, with squiggles and circles. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
