# Spotlight

Section: 3.1 AI effects
Video: Spotlight.mp4 (4 seconds, no sound)

## What it does
The room goes dark and a round light opens on your face and follows it.

## Best used when
A serious or secret moment, all eyes on you

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: the room goes dark and a round light opens on your face and follows it. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
