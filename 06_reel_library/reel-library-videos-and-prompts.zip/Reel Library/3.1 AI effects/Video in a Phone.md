# Video in a Phone

Section: 3.1 AI effects
Video: Video in a Phone.mp4 (4 seconds, no sound)

## What it does
Your video plays in one floating phone

## Best used when
Showing a reel or a phone screen

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: Your video plays in one floating phone. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
