# Angel Halo

Section: 3.1 AI effects
Video: Angel Halo.mp4 (4 seconds, no sound)

## What it does
A halo above your head that follows your face

## Best used when
A joke about being good or innocent

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: A halo above your head that follows your face. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
