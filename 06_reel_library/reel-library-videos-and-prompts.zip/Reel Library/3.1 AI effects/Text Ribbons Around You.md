# Text Ribbons Around You

Section: 3.1 AI effects
Video: Text Ribbons Around You.mp4 (4 seconds, no sound)

## What it does
Two text ribbons wrap around you: one behind your head, one across the front

## Best used when
Repeating a keyword, a brand moment

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: Two text ribbons wrap around you: one behind your head, one across the front. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
