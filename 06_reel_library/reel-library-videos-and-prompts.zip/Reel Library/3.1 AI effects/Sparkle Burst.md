# Sparkle Burst

Section: 3.1 AI effects
Video: Sparkle Burst.mp4 (4 seconds, no sound)

## What it does
Sparkles twinkle around your face

## Best used when
A pretty or magical moment

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: Sparkles twinkle around your face. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
