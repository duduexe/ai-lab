# Break Out of the Photo

Section: 3.1 AI effects
Video: Break Out of the Photo.mp4 (4 seconds, no sound)

## What it does
A tilted white instant-photo frame drops in, shakes, and your head breaks out over the top.

## Best used when
Breaking a rule, standing out, a fun moment

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: a tilted white instant-photo frame drops in, shakes, and your head breaks out over the top. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
