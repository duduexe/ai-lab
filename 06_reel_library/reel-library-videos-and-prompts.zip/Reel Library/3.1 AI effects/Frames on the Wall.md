# Frames on the Wall

Section: 3.1 AI effects
Video: Frames on the Wall.mp4 (4 seconds, no sound)

## What it does
Three frames swing in on their nails on the wall behind you and a neon word on a dark board flickers on (cut-out in front). images = pictures for the frames

## Best used when
Decorating your space with ideas or results

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: Three frames swing in on their nails on the wall behind you and a neon word on a dark board flickers on (cut-out in front). images = pictures for the frames. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
