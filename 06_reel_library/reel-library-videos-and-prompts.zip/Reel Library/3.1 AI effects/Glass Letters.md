# Glass Letters

Section: 3.1 AI effects
Video: Glass Letters.mp4 (4 seconds, no sound)

## What it does
One big word made of frosted glass: inside the letters the footage shows blurred and brighter, with a white rim and a shine; it sits behind your head (cut-out in front).

## Best used when
A premium title word behind your head

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: One big word made of frosted glass: inside the letters the footage shows blurred and brighter, with a white rim and a shine; it sits behind your head (cut-out in front).. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
