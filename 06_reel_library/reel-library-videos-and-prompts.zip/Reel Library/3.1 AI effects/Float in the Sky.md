# Float in the Sky

Section: 3.1 AI effects
Video: Float in the Sky.mp4 (4 seconds, no sound)

## What it does
Your room melts into a coloured sky with drifting clouds, you lift off and bob in the air (clouds in front hide where your cut-out ends), sparkles; at the end you come back down into your room.

## Best used when
A dreamy, relaxed or "free" feeling

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: Your room melts into a coloured sky with drifting clouds, you lift off and bob in the air (clouds in front hide where your cut-out ends), sparkles; at the end you come back down into your room.. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
