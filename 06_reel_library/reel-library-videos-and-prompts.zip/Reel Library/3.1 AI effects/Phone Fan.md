# Phone Fan

Section: 3.1 AI effects
Video: Phone Fan.mp4 (4 seconds, no sound)

## What it does
Your video plays on a phone; four more phones fan out behind it showing your past covers.

## Best used when
Showing your past videos or several examples

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: your video plays on a phone; four more phones fan out behind it showing your past covers. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
