# Speed Effect

Section: 3.1 AI effects
Video: Speed Effect.mp4 (4 seconds, no sound)

## What it does
Fast-forward feel: motion blur on your room, white speed lines rush past, two coloured ghosts of your trail behind you, a little shake, a bright ">> 2x" chip

## Best used when
Speeding through steps or time

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: Fast-forward feel: motion blur on your room, white speed lines rush past, two coloured ghosts of your trail behind you, a little shake, a bright ">> 2x" chip. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
