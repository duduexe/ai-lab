# Phone Carousel

Section: 3.1 AI effects
Video: Phone Carousel.mp4 (4 seconds, no sound)

## What it does
Phones turn like a merry-go-round around you; back phones fade behind you, front phones go over you

## Best used when
Many examples or apps around you

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: Phones turn like a merry-go-round around you; back phones fade behind you, front phones go over you. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
