# Sticker Outline

Section: 3.1 AI effects
Video: Sticker Outline.mp4 (4 seconds, no sound)

## What it does
A coloured sticker edge drawn around your cut-out, so you look like a sticker

## Best used when
You want to look cut out like a sticker over a graphic

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: a coloured sticker edge drawn around your cut-out, so you look like a sticker. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
