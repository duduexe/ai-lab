# Blend Mode Words

Section: 3.1 AI effects
Video: Blend Mode Words.mp4 (4 seconds, no sound)

## What it does
Big words slide across you in a blend mode so the letters change colour over you and the room

## Best used when
A stylish word moment that plays with your image

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: Big words slide across you in a blend mode so the letters change colour over you and the room; text "BLEND. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
