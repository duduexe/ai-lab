# Clones Behind You

Section: 3.1 AI effects
Video: Clones Behind You.mp4 (4 seconds, no sound)

## What it does
Six copies of you pop in behind you, smaller and further back, each a quarter of a second "late", so they move slightly differently.

## Best used when
Talking about doing many things at once or "everyone"

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: six copies of you pop in behind you, smaller and further back, each a quarter of a second "late", so they move slightly differently. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
