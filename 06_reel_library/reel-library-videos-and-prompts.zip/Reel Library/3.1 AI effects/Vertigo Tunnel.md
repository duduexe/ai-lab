# Vertigo Tunnel

Section: 3.1 AI effects
Video: Vertigo Tunnel.mp4 (4 seconds, no sound)

## What it does
You stay the same size while a coloured grid tunnel behind you rushes toward the camera (the famous "Vertigo" film trick, where the background stretches but the person does not).

## Best used when
A dramatic realisation

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: you stay the same size while a coloured grid tunnel behind you rushes toward the camera (the famous "Vertigo" film trick, where the background stretches but the person does not). Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
