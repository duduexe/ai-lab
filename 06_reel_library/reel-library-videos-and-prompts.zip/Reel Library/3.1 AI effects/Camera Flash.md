# Camera Flash

Section: 3.1 AI effects
Video: Camera Flash.mp4 (4 seconds, no sound)

## What it does
A camera viewfinder (four white corners, bright REC dot) with white flashes and a coloured and bright light leak at chosen times. Option hud: the word hud in label keeps the viewfinder on with no flash (add times to flash too, "hud,1.2"), with a running REC time, 9:16 and the frame rate. Option track: the word track adds a box with corner marks that follows your face (needs the face positions)

## Best used when
A photo moment or a flash of an idea; hud and track for a filmed, "on camera" feel over a whole part

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A camera viewfinder (four white corners, bright REC dot) with white flashes and a coloured and bright light leak at chosen times. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
