# Label That Follows You

Section: 3.1 AI effects
Video: Label That Follows You.mp4 (4 seconds, no sound)

## What it does
A bright label sticks next to your head and follows you as you move

## Best used when
Naming who you are or what you do

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: a bright label sticks next to your head and follows you. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
