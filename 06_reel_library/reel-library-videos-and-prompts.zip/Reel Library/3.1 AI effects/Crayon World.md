# Crayon World

Section: 3.1 AI effects
Video: Crayon World.mp4 (4 seconds, no sound)

## What it does
A wobbly crayon world appears around you: a rainbow behind your head and a spinning sun (behind your cut-out), two bees looping around you with dotted trails, a doodle dog peeking in, grass growing at the bottom

## Best used when
A playful, childlike or "imagine" moment

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: A wobbly crayon world appears around you: a rainbow behind your head and a spinning sun (behind your cut-out), two bees looping around you with dotted trails, a doodle dog peeking in, grass growing at the bottom. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
