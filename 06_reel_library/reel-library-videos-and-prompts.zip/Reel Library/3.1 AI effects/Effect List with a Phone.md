# Effect List with a Phone

Section: 3.1 AI effects
Video: Effect List with a Phone.mp4 (4 seconds, no sound)

## What it does
Two see-through glass cards at the top keep a numbered list of effect names, the current one lights up bright, while a phone on the left plays your clip with that look

## Best used when
Presenting a list of effects or tips one by one

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: Two see-through glass cards at the top keep a numbered list of effect names, the current one lights up bright, while a phone on the left plays your clip with that look

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
