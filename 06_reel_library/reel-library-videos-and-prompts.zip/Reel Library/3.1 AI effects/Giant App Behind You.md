# Giant App Behind You

Section: 3.1 AI effects
Video: Giant App Behind You.mp4 (4 seconds, no sound)

## What it does
You stand inside a giant made-up app screen that drifts past behind you

## Best used when
Living inside an app or a tool

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: You stand inside a giant made-up app screen that drifts past. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
