# Title Orbit

Section: 3.1 AI effects
Video: Title Orbit.mp4 (4 seconds, no sound)

## What it does
A bright ring with your title in letters travelling around your head. The back half passes behind your head.

## Best used when
Introducing yourself or the topic of the video

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: a bright ring with your title in letters travelling around your head. The back half passes behind your head. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
