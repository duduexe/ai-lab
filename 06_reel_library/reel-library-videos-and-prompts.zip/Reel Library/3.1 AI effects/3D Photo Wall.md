# 3D Photo Wall

Section: 3.1 AI effects
Video: 3D Photo Wall.mp4 (4 seconds, no sound)

## What it does
A wall of photos floats in 3D behind you and drifts (cut-out in front), a toggle flips on, a "New follower" notification drops in, one big white word at a time (images = photos

## Best used when
Showing many pictures or a collection

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: A wall of photos floats in 3D behind you and drifts (cut-out in front), a toggle flips on, a "New follower" notification drops in, one big white word at a time (images = photos. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
