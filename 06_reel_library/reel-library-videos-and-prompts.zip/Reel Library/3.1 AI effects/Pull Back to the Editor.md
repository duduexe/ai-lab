# Pull Back to the Editor

Section: 3.1 AI effects
Video: Pull Back to the Editor.mp4 (4 seconds, no sound)

## What it does
The camera pulls back and your video is inside a made-up "Reel edit" window with coloured clips, a bright clip, a sound wave and a moving playhead. It is drawn by us, it is not a real app.

## Best used when
Showing how the video was made

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: the camera pulls back and your video is inside a made-up "Reel edit" window with coloured clips, a bright clip, a sound wave and a moving playhead. It is drawn by us, it is not a real app. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
