# Orbit Around

Section: 3.1 AI effects
Video: Orbit Around.mp4 (4 seconds, no sound)

## What it does
Five little objects (bright sparkle, coloured planet, bright star, "AI" chip, bright dot) circle around your head on a tilted dotted ring, the back half behind your (cut-out).

## Best used when
Ideas or tools circling around you

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: Five little objects (bright sparkle, coloured planet, bright star, "AI" chip, bright dot) circle around your head on a tilted dotted ring, the back half behind your (cut-out).. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
