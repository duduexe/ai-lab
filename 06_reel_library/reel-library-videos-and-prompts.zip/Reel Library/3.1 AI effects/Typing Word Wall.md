# Typing Word Wall

Section: 3.1 AI effects
Video: Typing Word Wall.mp4 (4 seconds, no sound)

## What it does
Your background becomes a wall of words typing in on pale, one word boxed in bright, you in front.

## Best used when
A topic full of words: prompts, ideas, notes

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: your background becomes a wall of words typing in on pale, one word boxed in bright, you in front. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
