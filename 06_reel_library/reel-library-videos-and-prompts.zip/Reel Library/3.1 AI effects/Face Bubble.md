# Face Bubble

Section: 3.1 AI effects
Video: Face Bubble.mp4 (4 seconds, no sound)

## What it does
Only your face, in a round bubble with a coloured ring and a dark edge, pops in over a screen recording or graphic that covers your footage, bobs a little, a bright sparkle, pops out

## Best used when
Keeping your face on screen while a recording covers you

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: Only your face, in a round bubble with a coloured ring and a dark edge, pops in over a screen recording or graphic that covers your footage, bobs a little, a bright sparkle, pops out. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
