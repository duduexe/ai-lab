# New Background

Section: 3.1 AI effects
Video: New Background.mp4 (4 seconds, no sound)

## What it does
Your room is swapped for a new background (a picture or the coloured stage), you stay in front

## Best used when
You are in a new place or the room distracts

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: Your room is swapped for a new background (a picture or the coloured stage), you stay in front. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
