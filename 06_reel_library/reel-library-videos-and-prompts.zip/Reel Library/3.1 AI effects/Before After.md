# Before After

Section: 3.1 AI effects
Video: Before After.mp4 (4 seconds, no sound)

## What it does
A white line wipes across, the right half becomes the coloured grid stage, "Before" (white) and "After" (bright) pills, you in front. We keep your room in its real colours (he shows his room in black and white).

## Best used when
Comparing before and after

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: a white line wipes across, the right half becomes the coloured grid stage, "Before" (white) and "After" (bright) pills, you in front. We keep your room in its real colours (he shows his room in black and white). Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
