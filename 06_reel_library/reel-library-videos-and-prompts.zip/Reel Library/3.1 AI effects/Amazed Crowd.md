# Amazed Crowd

Section: 3.1 AI effects
Video: Amazed Crowd.mp4 (4 seconds, no sound)

## What it does
Full-screen meme: little yellow cartoon characters looking up, amazed; your cut-out in the crowd, your shirt fading below

## Best used when
A meme moment where everyone is amazed

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: Full-screen meme: little yellow cartoon characters looking up, amazed; your cut-out in the crowd, your shirt fading below. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
