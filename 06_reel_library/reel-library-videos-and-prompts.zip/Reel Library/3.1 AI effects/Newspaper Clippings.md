# Newspaper Clippings

Section: 3.1 AI effects
Video: Newspaper Clippings.mp4 (4 seconds, no sound)

## What it does
Torn paper clippings pop up around you (some behind you), the big one in front with a coloured highlight

## Best used when
News, headlines, "everyone is talking about it"

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: Torn paper clippings pop up around you (some behind you), the big one in front with a coloured highlight. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
