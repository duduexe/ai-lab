# Room Builds Behind You

Section: 3.1 AI effects
Video: Room Builds Behind You.mp4 (4 seconds, no sound)

## What it does
You stand on the coloured stage (cut-out) while your room builds itself behind you tile by tile from the bottom up, each tile landing with a white edge

## Best used when
Building something step by step

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: You stand on the coloured stage (cut-out) while your room builds itself behind you tile by tile from the bottom up, each tile landing with a white edge. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
