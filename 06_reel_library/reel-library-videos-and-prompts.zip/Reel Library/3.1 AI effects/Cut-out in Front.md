# Cut-out in Front

Section: 3.1 AI effects
Video: Cut-out in Front.mp4 (4 seconds, no sound)

## What it does
Your whole body, cut out, stands in front of a screen recording or graphic that covers your footage, exactly where you are in the clip, no ring or shapes, only a soft shadow; fades in and out

## Best used when
Standing in front of a screen recording you talk about

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: Your whole body, cut out, stands in front of a screen recording or graphic that covers your footage, exactly where you are in the clip, no ring or shapes, only a soft shadow; fades in and out. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Cut-out made with Robust Video Matting (GPL-3.0)

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
