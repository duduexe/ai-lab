# Head Out of the Card

Section: 3.1 AI effects
Video: Head Out of the Card.mp4 (4 seconds, no sound)

## What it does
Your video in a rounded card on the coloured stage; your head rises out of the top of the card.

## Best used when
An intro on a clean stage

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: your video in a rounded card on the coloured stage; your head rises out of the top of the card. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
