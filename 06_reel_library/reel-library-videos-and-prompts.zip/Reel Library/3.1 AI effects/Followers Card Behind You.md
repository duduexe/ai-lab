# Followers Card Behind You

Section: 3.1 AI effects
Video: Followers Card Behind You.mp4 (4 seconds, no sound)

## What it does
A glass profile card (posts, followers, following) behind your head, notification on top. Optional Follow button: a click time adds a bright Follow button that a mouse cursor clicks, it turns into "Following" and the count goes up. Option glass with: the same card with a FOLLOW button that turns into FOLLOWING, the number rolling up and a "New follower" pill. Option small profile card: profile picture, name and a link line that gets a hand-drawn circle and a cursor tap (added

## Best used when
Growth, followers, social proof

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: A glass profile card (posts, followers, following) behind your head, notification on top. Optional Follow button: a 4th label number (click time in seconds, "9. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
