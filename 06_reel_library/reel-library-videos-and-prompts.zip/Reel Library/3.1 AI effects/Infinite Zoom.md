# Infinite Zoom

Section: 3.1 AI effects
Video: Infinite Zoom.mp4 (4 seconds, no sound)

## What it does
A small white-framed copy of your video sits in the top right; the camera keeps diving into it, endlessly.

## Best used when
A loop, recursion or "it never ends"

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: a small white-framed copy of your video sits in the top right; the camera keeps diving into it, endlessly. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
