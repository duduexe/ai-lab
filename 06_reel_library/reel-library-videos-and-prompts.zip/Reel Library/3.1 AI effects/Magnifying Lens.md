# Magnifying Lens

Section: 3.1 AI effects
Video: Magnifying Lens.mp4 (4 seconds, no sound)

## What it does
A lens with a dark handle glides in and shows a 2x close-up of what is under it (in the preview, your face).

## Best used when
Pointing at a detail ("look closely")

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: a lens with a dark handle glides in and shows a 2x close-up of what is under it (in the preview, your face). Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
