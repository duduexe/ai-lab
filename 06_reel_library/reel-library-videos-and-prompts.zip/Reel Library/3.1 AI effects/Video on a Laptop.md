# Video on a Laptop

Section: 3.1 AI effects
Video: Video on a Laptop.mp4 (4 seconds, no sound)

## What it does
The camera pulls back and your video is playing on a drawn laptop on the coloured stage. Option glass: a slim laptop with no thick outlines and a soft reflection; the picture shrinks smoothly from the full screen into the laptop screen and pushes back in at the end (added

## Best used when
Talking about your work, a screen or a course

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: the camera pulls back and your video is playing on a drawn laptop on the coloured stage. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
