# Covers Behind You

Section: 3.1 AI effects
Video: Covers Behind You.mp4 (4 seconds, no sound)

## What it does
Your own past covers fly out and float behind you.

## Best used when
Showing your channel or past work

## Prompt to make it from scratch
A video effect made with code that uses the speaker's face position and a see-through cut-out of you: your own past covers fly out and float behind you. Comes in and goes out softly, never covers your face, keeps your footage colours.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
