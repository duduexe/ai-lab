# Shape Morph

Section: 4.8 Motion animations
Video: Shape Morph.mp4 (4 seconds, no sound)

## What it does
A soft blob keeps changing shape and bounces

## Best used when
A full-screen graphic moment between talking parts, on a light background

## Prompt to make it from scratch
A looping motion graphic "Shape Morph" made with code: A soft blob keeps changing shape and bounces, on a coloured background, about 3 s, smooth physics-like motion.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
