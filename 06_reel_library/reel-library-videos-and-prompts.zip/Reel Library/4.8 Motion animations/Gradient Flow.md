# Gradient Flow

Section: 4.8 Motion animations
Video: Gradient Flow.mp4 (4 seconds, no sound)

## What it does
Soft colour bands flow like silk

## Best used when
A full-screen graphic moment between talking parts, on a light background

## Prompt to make it from scratch
A looping motion graphic "Gradient Flow" made with code: Soft colour bands flow like silk, on a coloured background, about 3 s, smooth physics-like motion.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
