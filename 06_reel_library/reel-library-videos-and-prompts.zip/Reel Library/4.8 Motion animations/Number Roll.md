# Number Roll

Section: 4.8 Motion animations
Video: Number Roll.mp4 (4 seconds, no sound)

## What it does
Digits roll like a slot machine to the value, bars grow underneath

## Best used when
A full-screen graphic moment between talking parts, on a light background

## Prompt to make it from scratch
A looping motion graphic "Number Roll" made with code: Digits roll like a slot machine to the value, bars grow underneath, on a coloured background, about 3 s, smooth physics-like motion.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
