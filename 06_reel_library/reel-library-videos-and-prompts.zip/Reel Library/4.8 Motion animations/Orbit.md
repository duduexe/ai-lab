# Orbit

Section: 4.8 Motion animations
Video: Orbit.mp4 (4 seconds, no sound)

## What it does
A glowing planet with rings and a small moon going round it

## Best used when
A full-screen graphic moment between talking parts, on a light background

## Prompt to make it from scratch
A looping motion graphic "Orbit" made with code: A glowing planet with rings and a small moon going round it, on a coloured background, about 3 s, smooth physics-like motion.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
