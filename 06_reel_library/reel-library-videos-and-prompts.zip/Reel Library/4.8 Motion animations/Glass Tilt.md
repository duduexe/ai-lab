# Glass Tilt

Section: 4.8 Motion animations
Video: Glass Tilt.mp4 (4 seconds, no sound)

## What it does
A frosted glass card tilts in 3D with a light sheen sliding over it

## Best used when
A full-screen graphic moment between talking parts, on a light background

## Prompt to make it from scratch
A looping motion graphic "Glass Tilt" made with code: A frosted glass card tilts in 3D with a light sheen sliding over it, on a coloured background, about 3 s, smooth physics-like motion.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
