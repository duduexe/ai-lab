# Glass Tilt

Section: 4.8 Motion animations
Video: Glass Tilt.mp4 (4 seconds, no sound)

## What it does
A frosted glass card tilts in 3D with a light sheen sliding over it. Option skill card: a frosted glass card with the Claude spark tilts in 3D, a glow runs once around its edge, then it turns over into a checklist whose lines get ticked one by one (added. Option split step 3 (splitStepSkill, for the top half of a split screen with the same panel and step pill: the SKILL.md card tilts in the middle, a glow runs around it, it slides left and opens into a checklist ticked line by line, the Claude spark appears on the right in a glass circle, small lines of light run from the list to it while it spins, then three example videos pop out of it and get bright tick badges with bright sparkles

## Best used when
A full-screen graphic moment between talking parts, on a light background

## Prompt to make it from scratch
A looping motion graphic "Glass Tilt" made with code: A frosted glass card tilts in 3D with a light sheen sliding over it, on a coloured background, about 3 s, smooth physics-like motion.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
