# Phone Explode

Section: 4.8 Motion animations
Video: Phone Explode.mp4 (4 seconds, no sound)

## What it does
The layers of a phone lift apart (exploded view), then click back together

## Best used when
A full-screen graphic moment between talking parts, on a light background

## Prompt to make it from scratch
A looping motion graphic "Phone Explode" made with code: The layers of a phone lift apart (exploded view), then click back together, on a coloured background, about 3 s, smooth physics-like motion.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
