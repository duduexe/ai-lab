# Confetti Burst

Section: 4.8 Motion animations
Video: Confetti Burst.mp4 (4 seconds, no sound)

## What it does
A check badge pops and confetti bursts out, with "You're live"

## Best used when
A full-screen graphic moment between talking parts, on a light background

## Prompt to make it from scratch
A looping motion graphic "Confetti Burst" made with code: A check badge pops and confetti bursts out, with "You're live", on a coloured background, about 3 s, smooth physics-like motion.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
