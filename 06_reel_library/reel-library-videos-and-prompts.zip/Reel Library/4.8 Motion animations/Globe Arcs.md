# Globe Arcs

Section: 4.8 Motion animations
Video: Globe Arcs.mp4 (4 seconds, no sound)

## What it does
A dotted globe spins and arcs draw between places

## Best used when
A full-screen graphic moment between talking parts, on a light background

## Prompt to make it from scratch
A looping motion graphic "Globe Arcs" made with code: A dotted globe spins and arcs draw between places, on a coloured background, about 3 s, smooth physics-like motion.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
