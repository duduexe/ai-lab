# Button Press

Section: 4.8 Motion animations
Video: Button Press.mp4 (4 seconds, no sound)

## What it does
A cursor presses a button, it fills and turns into "Posted ✓"

## Best used when
A full-screen graphic moment between talking parts, on a light background

## Prompt to make it from scratch
A looping motion graphic "Button Press" made with code: A cursor presses a button, it fills and turns into "Posted ✓", on a coloured background, about 3 s, smooth physics-like motion.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
