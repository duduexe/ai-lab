# Cards Shuffle

Section: 4.8 Motion animations
Video: Cards Shuffle.mp4 (4 seconds, no sound)

## What it does
A stack of cards; the back card swoops to the front, over and over

## Best used when
A full-screen graphic moment between talking parts, on a light background

## Prompt to make it from scratch
A looping motion graphic "Cards Shuffle" made with code: A stack of cards; the back card swoops to the front, over and over, on a coloured background, about 3 s, smooth physics-like motion.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
