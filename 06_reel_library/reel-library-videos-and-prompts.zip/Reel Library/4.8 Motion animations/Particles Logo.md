# Particles Logo

Section: 4.8 Motion animations
Video: Particles Logo.mp4 (4 seconds, no sound)

## What it does
A cloud of dots flies together into a sparkle logo

## Best used when
A full-screen graphic moment between talking parts, on a light background

## Prompt to make it from scratch
A looping motion graphic "Particles Logo" made with code: A cloud of dots flies together into a sparkle logo, on a coloured background, about 3 s, smooth physics-like motion.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
