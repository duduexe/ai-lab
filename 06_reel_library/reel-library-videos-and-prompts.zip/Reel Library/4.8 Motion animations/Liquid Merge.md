# Liquid Merge

Section: 4.8 Motion animations
Video: Liquid Merge.mp4 (4 seconds, no sound)

## What it does
Two drops drift together and melt into one

## Best used when
A full-screen graphic moment between talking parts, on a light background

## Prompt to make it from scratch
A looping motion graphic "Liquid Merge" made with code: Two drops drift together and melt into one, on a coloured background, about 3 s, smooth physics-like motion.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
