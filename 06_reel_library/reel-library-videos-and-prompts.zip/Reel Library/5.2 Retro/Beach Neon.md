# Beach Neon

Section: 5.2 Retro
Video: Beach Neon.mp4 (4 seconds, no sound)

## What it does
Rich colours

## Best used when
Bright summer fun

## Prompt to make it from scratch
A colour filter for talking-head footage: rich colours. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
