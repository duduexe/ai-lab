# Golden Age Cinema

Section: 5.2 Retro
Video: Golden Age Cinema.mp4 (4 seconds, no sound)

## What it does
Warm, muted colours, film grain, faded blacks

## Best used when
An old movie feel

## Prompt to make it from scratch
A colour filter for talking-head footage: warm, muted colours, film grain, faded blacks. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
