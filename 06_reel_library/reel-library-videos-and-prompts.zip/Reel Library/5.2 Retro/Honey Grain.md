# Honey Grain

Section: 5.2 Retro
Video: Honey Grain.mp4 (4 seconds, no sound)

## What it does
Warm, film grain

## Best used when
Warm, filmic memories

## Prompt to make it from scratch
A colour filter for talking-head footage: warm, film grain. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
