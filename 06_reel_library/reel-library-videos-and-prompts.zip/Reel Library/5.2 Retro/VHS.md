# VHS

Section: 5.2 Retro
Video: VHS.mp4 (4 seconds, no sound)

## What it does
Muted colours, soft contrast, film grain, faded blacks

## Best used when
90s and home-video jokes

## Prompt to make it from scratch
A colour filter for talking-head footage: muted colours, soft contrast, film grain, faded blacks. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
