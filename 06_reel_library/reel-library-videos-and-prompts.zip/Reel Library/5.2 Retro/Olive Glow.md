# Olive Glow

Section: 5.2 Retro
Video: Olive Glow.mp4 (4 seconds, no sound)

## What it does
Warm, faded blacks

## Best used when
A warm, earthy vibe

## Prompt to make it from scratch
A colour filter for talking-head footage: warm, faded blacks. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
