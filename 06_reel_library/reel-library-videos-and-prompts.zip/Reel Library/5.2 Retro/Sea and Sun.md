# Sea and Sun

Section: 5.2 Retro
Video: Sea and Sun.mp4 (4 seconds, no sound)

## What it does
Light touch

## Best used when
Beach and travel

## Prompt to make it from scratch
A colour filter for talking-head footage: light touch. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
