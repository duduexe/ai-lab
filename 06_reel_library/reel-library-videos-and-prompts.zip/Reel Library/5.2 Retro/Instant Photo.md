# Instant Photo

Section: 5.2 Retro
Video: Instant Photo.mp4 (4 seconds, no sound)

## What it does
Muted colours, soft contrast, faded blacks

## Best used when
Memories and soft nostalgia

## Prompt to make it from scratch
A colour filter for talking-head footage: muted colours, soft contrast, faded blacks. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
