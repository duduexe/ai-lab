# Teal and orange cinematic grade

Section: 7.1 Visual style
Video: Teal and orange cinematic grade.mp4 (4 seconds, no sound)

## What it does
Colours: "shadows and backgrounds pushed toward cool blue-green (teal) while skin tones and highlights are pushed warm toward orange"; dramatic lighting

Graphic language: Film grade

## Best used when
A cinematic, movie-like story

## Prompt to make it from scratch
Style a whole talking-head video in a "Teal and orange cinematic grade" look. Colours: "shadows and backgrounds pushed toward cool blue-green (teal) while skin tones and highlights are pushed warm toward orange"; dramatic lighting; graphic language: Film grade. Keep it readable and inside the safe zones.

## Source
Morphic: teal and orange, standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
