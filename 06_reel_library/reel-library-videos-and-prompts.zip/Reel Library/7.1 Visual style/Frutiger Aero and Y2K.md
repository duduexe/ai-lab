# Frutiger Aero and Y2K

Section: 7.1 Visual style
Video: Frutiger Aero and Y2K.mp4 (4 seconds, no sound)

## What it does
Colours: "glossy gradients", "transparent blues"

Graphic language: "skeuomorphic buttons", "optimistic digital tech motifs", early 2000s

## Best used when
Nostalgic tech or the early internet

## Prompt to make it from scratch
Style a whole talking-head video in a "Frutiger Aero and Y2K" look. Colours: "glossy gradients", "transparent blues"; graphic language: "skeuomorphic buttons", "optimistic digital tech motifs", early 2000s. Keep it readable and inside the safe zones.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
