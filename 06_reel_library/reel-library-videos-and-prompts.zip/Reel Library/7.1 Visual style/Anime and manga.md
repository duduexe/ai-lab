# Anime and manga

Section: 7.1 Visual style
Video: Anime and manga.mp4 (4 seconds, no sound)

## What it does
Colours: "ranging from clean cel-shaded look to detailed black-and-white panel action"

Graphic language: "Japanese-inspired character art"

## Best used when
Dramatic or funny reactions

## Prompt to make it from scratch
Style a whole talking-head video in a "Anime and manga" look. Colours: "ranging from clean cel-shaded look to detailed black-and-white panel action"; graphic language: "Japanese-inspired character art". Keep it readable and inside the safe zones.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
