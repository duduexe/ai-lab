# Flat design

Section: 7.1 Visual style
Video: Flat design.mp4 (4 seconds, no sound)

## What it does
Colours: Solid colours, no depth

Graphic language: "Simple geometric shapes and solid colors with little or no depth"; Kurzgesagt: "vector illustration, pixel-based illustration, and infographics"

## Best used when
Explaining an idea simply with shapes

## Prompt to make it from scratch
Style a whole talking-head video in a "Flat design" look. Colours: Solid colours, no depth; graphic language: "Simple geometric shapes and solid colors with little or no depth"; Kurzgesagt: "vector illustration, pixel-based illustration, and infographics". Keep it readable and inside the safe zones.

## Source
Videomaker on flat design, Kurzgesagt

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
