# Art Deco and Art Nouveau

Section: 7.1 Visual style
Video: Art Deco and Art Nouveau.mp4 (4 seconds, no sound)

## What it does
Colours: "geometric luxury gold/sharp lines from the 1920s (Art Deco) or flowing, nature-inspired organic curves (Art Nouveau)"

Graphic language: Geometric lines or organic curves

## Best used when
Luxury, elegant or historical topics

## Prompt to make it from scratch
Style a whole talking-head video in a "Art Deco and Art Nouveau" look. Colours: "geometric luxury gold/sharp lines from the 1920s (Art Deco) or flowing, nature-inspired organic curves (Art Nouveau)"; graphic language: Geometric lines or organic curves. Keep it readable and inside the safe zones.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
