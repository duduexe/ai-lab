# Brutalism and neo-brutalism

Section: 7.1 Visual style
Video: Brutalism and neo-brutalism.mp4 (4 seconds, no sound)

## What it does
Colours: "high-contrast monochrome palettes"

Graphic language: "Raw, unpolished, stark layouts", "anti-aesthetic grid structures"

## Best used when
Bold opinions and design topics

## Prompt to make it from scratch
Style a whole talking-head video in a "Brutalism and neo-brutalism" look. Colours: "high-contrast monochrome palettes"; graphic language: "Raw, unpolished, stark layouts", "anti-aesthetic grid structures". Keep it readable and inside the safe zones.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
