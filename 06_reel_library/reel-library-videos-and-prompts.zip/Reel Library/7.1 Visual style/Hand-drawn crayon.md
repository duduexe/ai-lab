# Hand-drawn crayon

Section: 7.1 Visual style
Video: Hand-drawn crayon.mp4 (4 seconds, no sound)

## What it does
Colours: Crayon-drawn look, purple glow

Text: Small purple glowing captions

Graphic language: Crayon-drawn cartoon world

## Best used when
Playful, childlike or imaginative topics

## Prompt to make it from scratch
Style a whole talking-head video in a "Hand-drawn crayon" look. Colours: Crayon-drawn look, purple glow; text: Small purple glowing captions; graphic language: Crayon-drawn cartoon world. Keep it readable and inside the safe zones.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
