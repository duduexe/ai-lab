# Cyberpunk and synthwave

Section: 7.1 Visual style
Video: Cyberpunk and synthwave.mp4 (4 seconds, no sound)

## What it does
Colours: "Neon-drenched", dark urban or retro-futuristic

Graphic language: "high-tech" electronic aesthetics

## Best used when
Tech, AI and future topics

## Prompt to make it from scratch
Style a whole talking-head video in a "Cyberpunk and synthwave" look. Colours: "Neon-drenched", dark urban or retro-futuristic; graphic language: "high-tech" electronic aesthetics. Keep it readable and inside the safe zones.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
