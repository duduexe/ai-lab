# Paper craft collage

Section: 7.1 Visual style
Video: Paper craft collage.mp4 (4 seconds, no sound)

## What it does
Colours: Cream paper, old-print tones

Text: Typewriter titles

Graphic language: "Torn-paper collage", a paper hole that opens on a scene

## Best used when
Storytelling and explainers with a handmade feel

## Prompt to make it from scratch
Style a whole talking-head video in a "Paper craft collage" look. Colours: Cream paper, old-print tones; text: Typewriter titles; graphic language: "Torn-paper collage", a paper hole that opens on a scene. Keep it readable and inside the safe zones.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
