# Paper craft collage

Section: 7.1 Visual style
Video: Paper craft collage.mp4 (4 seconds, no sound)

## What it does
Colours: Cream paper, old-print tones

Text: Typewriter titles

Graphic language: "Torn-paper collage", a paper hole that opens on a scene

## Best used when
Storytelling and explainers with a handmade feel

## Prompt to make it from scratch
Style a whole talking-head video in a "Paper craft collage" look. Colours: Cream paper, old-print tones; text: Typewriter titles; graphic language: "Torn-paper collage", a paper hole that opens on a scene. Keep it readable and inside the safe zones.. Built as an effect on: the picture tears open, you are cut out with a white torn paper edge and moves in small steps, torn lilac paper layers with grain, an orange halftone sun, tape and four paper shapes; cleaner version on lilac paper, no cream. Option: with no cut-out it switches to a photo print, your live picture in a torn white paper print held by tape, on a dark purple front strip so captions stay readable (use it when no clean cut-out can be made). Photo print look v3: real torn paper with a white paper core on every edge, a dotted lilac page, an orange halftone scrap and a lined lilac scrap, the print placed on the page by hand and held by see-through tape, two lime paper sparkles, a lilac and a dark purple torn strip at the bottom, all in stop motion with a small handmade jitter; at the end the papers fly off and the print turns straight and grows into the full video, so it goes back to the footage without a cut. Star cameo look: a lilac gingham page with lime paper sparkles, a big lilac paper star burst, your live talking face cut out in a torn oval with a white paper edge and kept in its middle by a face track (build/face_track_skin.py, no cut-out tool needed), a ransom-note word made of paper letters above your head, eight paper stickers (clapperboard, film strip, heart, phone, play button, scissors, camera, star) popping in one by one around you, a dark purple torn strip behind the captions; at the end your picture lines up with the video and the cut-out opens up into it. Library example, from Reel Library 2, your choice): the star cameo look replaces the old drawn sample; its exact settings are in previews/261113_paper_collage_star_cameo.json and in the Build tab item "Paper craft collage" (paperCollage in, with your clip and face track from that video

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
