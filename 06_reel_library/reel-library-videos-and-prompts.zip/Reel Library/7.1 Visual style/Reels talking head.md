# Reels talking head

Section: 7.1 Visual style
Video: Reels talking head.mp4 (4 seconds, no sound)

## What it does
Colours: Natural footage colours on a neutral studio background (soft white and warm grey, with a light floor grid); white and black text with one yellow highlight word

Text: Bold white captions with a black outline in the middle of the screen, one highlighted word; a short hook in a white box at the top in the first seconds

Graphic language: Quick emoji stickers, punch-in zooms on key words, simple pop-up cards, sometimes a thin progress bar

## Best used when
Any creator or client who wants the usual, unbranded talking-head reel look

## Prompt to make it from scratch
Style a whole talking-head reel in the usual unbranded Reels look: the speaker cut out on a neutral studio background (soft white to warm grey, a light floor grid), natural footage colours, a short hook in a white box at the top for the first 2 to 3 seconds, bold white captions with a black outline in the middle of the screen with one yellow highlighted word, quick emoji stickers and punch-in zooms on key words. Keep everything inside the platform safe zones.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
