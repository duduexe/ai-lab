# Vintage plate and engraving

Section: 7.1 Visual style
Video: Vintage plate and engraving.mp4 (4 seconds, no sound)

## What it does
Colours: Cream paper grain, gold, dark green, pink watercolour

Text: Typewriter captions, museum "PLATE VII" title page, pixel-font labels, red stamp call to action

Graphic language: Old botanical engravings, thin construction lines, close-up boxes

## Best used when
History, knowledge or a classy topic

## Prompt to make it from scratch
Style a whole talking-head video in a "Vintage plate and engraving" look. Colours: Cream paper grain, gold, dark green, pink watercolour; text: Typewriter captions, museum "PLATE VII" title page, pixel-font labels, red stamp call to action; graphic language: Old botanical engravings, thin construction lines, close-up boxes. Keep it readable and inside the safe zones.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
