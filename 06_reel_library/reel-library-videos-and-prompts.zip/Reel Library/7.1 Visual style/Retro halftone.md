# Retro halftone

Section: 7.1 Visual style
Video: Retro halftone.mp4 (4 seconds, no sound)

## What it does
Colours: Black and white halftone with a yellow label, retro textured backgrounds

Text: Serif headlines, white uppercase captions

Graphic language: Halftone cut-out people

## Best used when
News-style explainers and opinion pieces

## Prompt to make it from scratch
Style a whole talking-head video in a "Retro halftone" look. Colours: Black and white halftone with a yellow label, retro textured backgrounds; text: Serif headlines, white uppercase captions; graphic language: Halftone cut-out people. Keep it readable and inside the safe zones.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
