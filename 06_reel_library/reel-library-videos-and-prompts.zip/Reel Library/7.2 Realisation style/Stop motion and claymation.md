# Stop motion and claymation

Section: 7.2 Realisation style
Video: Stop motion and claymation.mp4 (4 seconds, no sound)

## What it does
Format: Physical objects

How it is made and paced: "Frame-by-frame photography of physical objects, paper cutouts, or molded clay giving a tactile, handmade feel"

## Best used when
Playful, handmade storytelling

## Prompt to make it from scratch
Make a short video as "Stop motion and claymation": format: Physical objects; how it is made and paced: "Frame-by-frame photography of physical objects, paper cutouts, or molded clay giving a tactile, handmade feel".

## Source
Mammoth, Antidoto56

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
