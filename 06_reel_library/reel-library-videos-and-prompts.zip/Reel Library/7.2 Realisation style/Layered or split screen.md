# Layered or split screen

Section: 7.2 Realisation style
Video: Layered or split screen.mp4 (4 seconds, no sound)

## What it does
Format: Collage of several layers; VOX: animation on top, speaker below, captions on the line between

How it is made and paced: Brainrot stack: talking head with gameplay underneath, ASMR audio, multicolour captions, cuts every 0.6 to 0.8 s (vendor blog)

## Best used when
Showing a screen or animation while you talk

## Prompt to make it from scratch
Make a short video as "Layered or split screen": format: Collage of several layers; VOX: animation on top, speaker below, captions on the line between; how it is made and paced: Brainrot stack: talking head with gameplay underneath, ASMR audio, multicolour captions, cuts every 0.6 to 0.8 s (vendor blog).

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
