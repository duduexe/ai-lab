# 3D animation and CGI

Section: 7.2 Realisation style
Video: 3D animation and CGI.mp4 (4 seconds, no sound)

## What it does
Format: Animated scenes

How it is made and paced: "Volumetric digital models with realistic depth, lighting, and textures, frequently used for product features and tech demos"

## Best used when
Products and tech demos

## Prompt to make it from scratch
Make a short video as "3D animation and CGI": format: Animated scenes; how it is made and paced: "Volumetric digital models with realistic depth, lighting, and textures, frequently used for product features and tech demos".

## Source
YouTube

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
