# Movie trailer

Section: 7.2 Realisation style
Video: Movie trailer.mp4 (4 seconds, no sound)

## What it does
Format: Horizontal, usually "2.39:1 ultrawide letterbox" (bars often added in post: "fake" 2.40:1 mattes); teaser 30 to 60 s, trailer 90 to 150 s

How it is made and paced: Slow zooms, speed ramps, cuts on music builds and climaxes; braam, sub drop, "hit and silence"; title-card text not in the sources

## Best used when
Launches and big announcements

## Prompt to make it from scratch
Make a short video as "Movie trailer": format: Horizontal, usually "2.39:1 ultrawide letterbox" (bars often added in post: "fake" 2.40:1 mattes); teaser 30 to 60 s, trailer 90 to 150 s; how it is made and paced: Slow zooms, speed ramps, cuts on music builds and climaxes; braam, sub drop, "hit and silence"; title-card text not in the sources.

## Source
zsky.ai trailer blog, Wikipedia: Letterboxing), Morphic: braam, standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
