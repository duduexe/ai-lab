# Kinetic typography

Section: 7.2 Realisation style
Video: Kinetic typography.mp4 (4 seconds, no sound)

## What it does
Format: Text-led

How it is made and paced: "Animated, fast-moving text and dynamic lettering used for product launches, title sequences, and brand intros"; Animated Text: text on green screen to key out

## Best used when
Quotes, launches and lists

## Prompt to make it from scratch
Make a short video as "Kinetic typography": format: Text-led; how it is made and paced: "Animated, fast-moving text and dynamic lettering used for product launches, title sequences, and brand intros"; Animated Text: text on green screen to key out.

## Source
Moonb, YouTube

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
