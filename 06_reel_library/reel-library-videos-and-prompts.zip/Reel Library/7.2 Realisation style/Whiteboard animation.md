# Whiteboard animation

Section: 7.2 Realisation style
Video: Whiteboard animation.mp4 (4 seconds, no sound)

## What it does
Format: Educational

How it is made and paced: "Hand-drawn line illustrations appearing step-by-step on a whiteboard, commonly used for educational or didactic content"

## Best used when
Teaching step by step

## Prompt to make it from scratch
Make a short video as "Whiteboard animation": format: Educational; how it is made and paced: "Hand-drawn line illustrations appearing step-by-step on a whiteboard, commonly used for educational or didactic content".

## Source
Antidoto56

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
