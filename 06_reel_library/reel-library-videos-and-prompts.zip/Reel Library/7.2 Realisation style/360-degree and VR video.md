# 360-degree and VR video

Section: 7.2 Realisation style
Video: 360-degree and VR video.mp4 (4 seconds, no sound)

## What it does
Format: Omnidirectional

How it is made and paced: "spatial immersive video views allowing interactive user perspective"

## Best used when
Immersive places

## Prompt to make it from scratch
Make a short video as "360-degree and VR video": format: Omnidirectional; how it is made and paced: "spatial immersive video views allowing interactive user perspective".

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
