# Mixed media

Section: 7.2 Realisation style
Video: Mixed media.mp4 (4 seconds, no sound)

## What it does
Format: Collage

How it is made and paced: "A collage combination of live-action footage, 2D/3D elements, stop motion, and graphic textures"; examples: Claude + InVideo motion graphics, paper collage explainers

## Best used when
Creative explainers with footage and drawings

## Prompt to make it from scratch
Make a short video as "Mixed media": format: Collage; how it is made and paced: "A collage combination of live-action footage, 2D/3D elements, stop motion, and graphic textures"; examples: Claude + InVideo motion graphics, paper collage explainers.

## Source
Mammoth, YouTube

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
