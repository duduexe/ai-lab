# Slot Reel Title

Section: 1.3 Animated titles
Video: Slot Reel Title.mp4 (4 seconds, no sound)

## What it does
A row of little windows; in each one a strip of letters runs down, slows and lands on the right letter with a bounce, left to right; at the end the shadows turn bright and two sparkles pop. Text: up to 3 short lines. Option: speed

## Best used when
A win, a pick or a surprise: "and the winner is", a random choice, a prize

## Prompt to make it from scratch
An animated title made with code for a 1080 x 1920 reel: one small upright window per letter (rounded corners, 4 px dark outline, hard dark shadow, light inside with a soft shade at the top and bottom edge). In every window a strip of random capital letters in a chunky rounded dark font runs downward fast, slows down and lands on the right letter with a small overshoot; the windows stop one after the other, 0.2 s apart, from left to right, and a stopped window turns white with a tiny bump. When the last one stops, all hard shadows turn bright and two four-point sparkles (one bright, one bright, dark outline) pop in at the top right and bottom left and turn slowly. Fades out at the end..

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
