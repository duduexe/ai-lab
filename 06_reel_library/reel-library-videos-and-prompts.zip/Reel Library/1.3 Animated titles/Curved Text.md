# Curved Text

Section: 1.3 Animated titles
Video: Curved Text.mp4 (4 seconds, no sound)

## What it does
Text that bends along an arch or runs all the way round a circle; the letters appear one after the other along the curve and the circle can spin. To make it pass behind your head, put your cut-out on a layer above it (Sticker Outline with thickness 0) (props text, shape arch or circle, x, y, radius, bend, font, size, color, spin, reveal)

## Best used when
A name, a slogan or a label that circles your head or arches over an object

## Prompt to make it from scratch
An animated title for a 1080 x 1920 reel: a short phrase set along a curve, either an arch (a bow of about 150 degrees over a middle point) or a full circle round it, radius about 360 px, centred on your head (x 540, y 820); the letters appear one after the other along the curve in 0.7 s; optional slow spin round the middle (degrees per second) (a bold subtitle font, a bold rounded title font, a handwritten script font or a small pixel-style label font), pale; your cut-out on a layer above so the text passes behind your head; fades out at the end.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
