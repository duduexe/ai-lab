# Big Word

Section: 1.3 Animated titles
Video: Big Word.mp4 (4 seconds, no sound)

## What it does
One word, very big, bounces in

## Best used when
One word is the whole point of the moment ("FREE", "WOW")

## Prompt to make it from scratch
An animated title for a 1080 x 1920 reel: One word, very big, bounces in. Brand fonts, pops in and fades out, inside the safe zone.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
