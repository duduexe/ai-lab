# Letter Tiles Title

Section: 1.3 Animated titles
Video: Letter Tiles Title.mp4 (4 seconds, no sound)

## What it does
Cut-out letters: every letter is its own crooked sticker tile in mixed colours and three fonts, slapped on one after the other; the last line is bright and single tiles keep hopping. Text: up to 4 short lines. Option: speed

## Best used when
A handmade, playful title: a tip list, a "how I made this", a fun fact

## Prompt to make it from scratch
An animated title made with code for a 1080 x 1920 reel, like letters cut out and glued on: each capital letter sits on its own flat tile (white, bright, light or coloured in a mixed order, bright for the whole last line; 4 px dark outline, hard dark shadow, slightly different corner rounding), each tile tilted a few degrees and a little higher or lower than its neighbour. The letters use three fonts in turn (a chunky rounded one, a handwritten one and a pixel one), in dark. The tiles are slapped on one after the other, 0.07 s apart: each starts twice as big and turned, drops into place and squashes a little. Afterwards one random tile at a time hops up and rocks. Fades out at the end..

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
