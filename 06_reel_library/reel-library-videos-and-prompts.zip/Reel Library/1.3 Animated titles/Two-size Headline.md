# Two-size Headline

Section: 1.3 Animated titles
Video: Two-size Headline.mp4 (4 seconds, no sound)

## What it does
One headline in two sizes: big bold key words (a bold rounded title font or a bold subtitle font) next to tiny italic words (an italic caption font); the words pop in one after the other and the last big word can be bright. Mark the big words with stars: `the *one* tool I *use* every *day*` (props text, bigFont title or subtitle, bigSize, smallSize, accentLast, y, gap)

## Best used when
A hook or a title where two or three words carry the whole message

## Prompt to make it from scratch
An animated title for a 1080 x 1920 reel: one headline where the key words are big and bold (a bold rounded title font or a bold subtitle font, about 150 px) and the words between them are tiny italic (an italic caption font, about 62 px), on shared lines, centred, top at y 330 (inside the safe zone); each word pops in 0.09 s after the one before; the last big word in bright, the rest light or dark; fades out at the end. Big words are the ones written between stars.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
