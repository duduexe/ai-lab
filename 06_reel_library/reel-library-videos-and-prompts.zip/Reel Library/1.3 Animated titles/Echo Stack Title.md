# Echo Stack Title

Section: 1.3 Animated titles
Video: Echo Stack Title.mp4 (4 seconds, no sound)

## What it does
The words slide in from the side with coloured copies trailing behind them; the copies settle under the word as a thick stack of layers (bright, coloured, bright, dark) that keeps breathing. Text: up to 3 lines. Option: speed

## Best used when
A loud, proud statement: a big claim, a title card, a chapter name

## Prompt to make it from scratch
An animated title made with code for a 1080 x 1920 reel: each line of chunky rounded letters (white fill, thick dark outline) shoots in from the side, the first line from the left and the second from the right, followed by four copies of itself in bright, coloured, bright and dark that arrive a moment later each, like an echo. The copies then slide out one by one, down and to the right, with a bounce, and stack under the word like thick layers of paper. While the title stays, the depth of the stack breathes slowly in a wave. Fades out at the end. light background or over the video.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
