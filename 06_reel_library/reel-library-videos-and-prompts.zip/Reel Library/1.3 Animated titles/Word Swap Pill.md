# Word Swap Pill

Section: 1.3 Animated titles
Video: Word Swap Pill.mp4 (4 seconds, no sound)

## What it does
A fixed line in sticker letters, and under it a tilted bright pill whose word rolls over to the next one; the pill stretches to fit each word, and the last word stays on a bright pill. Text: the fixed words, then the words that swap, each separated by a bar (for example: Make it, faster, smarter, yours). Option: speed

## Best used when
One sentence with several endings: benefits, options, "for work, for school, for you"

## Prompt to make it from scratch
An animated title made with code for a 1080 x 1920 reel: a first line in chunky rounded sticker letters (white fill, thick dark outline, hard dark shadow). Under it a pill-shaped sticker tilted 2.5 degrees (bright, 4 px dark outline, hard dark shadow) holding one dark word. Every 1.15 s the word rolls up and out of the pill while the next word rolls in from below with a bounce; the pill changes width with a springy overshoot to fit the new word and rocks a little. On the last word the pill turns bright and stays. Fades out at the end., inside the safe zone.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
