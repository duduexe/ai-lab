# Strike Through

Section: 1.3 Animated titles
Video: Strike Through.mp4 (4 seconds, no sound)

## What it does
A word or line gets crossed out with a marker line

## Best used when
You correct a myth or reject an old way

## Prompt to make it from scratch
An animated title for a 1080 x 1920 reel: A word or line gets crossed out with a marker line. Brand fonts, pops in and fades out, inside the safe zone.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
