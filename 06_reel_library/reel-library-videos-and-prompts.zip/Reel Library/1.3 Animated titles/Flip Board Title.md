# Flip Board Title

Section: 1.3 Animated titles
Video: Flip Board Title.mp4 (4 seconds, no sound)

## What it does
A departure board in a retro window: every tile flips through wrong letters and locks on the right one, left to right and line by line; the tiles of the last line turn bright. Text: up to 4 short lines, a bar starts a new line. Options: speed, label (the small name in the window bar)

## Best used when
You announce something: a new video, a date, a release, "next up"

## Prompt to make it from scratch
An animated title made with code for a 1080 x 1920 reel: a flat sticker window (bright title bar with three small squares and a small name in a pixel font, 4 px dark outline, hard 8 px dark shadow with no blur, light inside) holding up to four rows of white flip tiles with a split line across the middle, one capital letter per tile in a chunky rounded font. Each tile flips through random letters like a split-flap board (top half folds down, about 12 flips a second) and locks on its letter with a tiny bump, left to right, row after row; the tiles of the last row turn bright when they lock. The window pops in with a small bounce and fades out at the end., inside the safe zone (840 px wide).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
