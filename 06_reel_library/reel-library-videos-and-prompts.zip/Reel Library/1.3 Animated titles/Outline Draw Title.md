# Outline Draw Title

Section: 1.3 Animated titles
Video: Outline Draw Title.mp4 (4 seconds, no sound)

## What it does
The title is first a dashed plan in coloured, then a pen draws its dark outline, colour fills it from the left (white, the last line bright) and a hard shadow pops out. Text: up to 3 lines. Option: speed

## Best used when
Something is being made: a plan that becomes real, a design, a build, "from idea to done"

## Prompt to make it from scratch
An animated title made with code for a 1080 x 1920 reel: chunky rounded capitals on up to three lines. First only a thin dashed coloured outline of the letters shows, its dashes marching along. Then a solid dark outline is drawn over it like a pen following every letter (about 1.3 s, the second line starts 0.3 s later). When the outline is done the dashes fade, and the letters fill with colour in a wipe from left to right: white, and bright for the last line. Last, a hard dark shadow pops out from behind the letters, down and to the right, with a small overshoot. Fades out at the end. light background or over the video.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
