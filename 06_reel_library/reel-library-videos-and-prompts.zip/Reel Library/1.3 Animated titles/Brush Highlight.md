# Brush Highlight

Section: 1.3 Animated titles
Video: Brush Highlight.mp4 (4 seconds, no sound)

## What it does
Handwritten phrase on a coloured brush stroke, bright dash rays and underline, optional bold lines above

## Best used when
A handwritten phrase should feel personal, like a cover note

## Prompt to make it from scratch
An animated title for a 1080 x 1920 reel: Handwritten phrase on a coloured brush stroke, bright dash rays and underline, optional bold lines above. Brand fonts, pops in and fades out, inside the safe zone.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
