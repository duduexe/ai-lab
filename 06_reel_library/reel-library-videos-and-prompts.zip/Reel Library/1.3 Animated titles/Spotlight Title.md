# Spotlight Title

Section: 1.3 Animated titles
Video: Spotlight Title.mp4 (4 seconds, no sound)

## What it does
The title is only a pale coloured outline; a round bright spot wanders over it and shows the letters in full inside it, then grows until the whole title is lit, the last line in bright. Text: up to 3 lines. Option: speed

## Best used when
Something hidden gets found: a detail, a tip nobody noticed, "look closer"

## Prompt to make it from scratch
An animated title made with code for a 1080 x 1920 reel: the headline in chunky rounded capitals is first drawn only as a pale ghost (see-through white fill, thick coloured outline). A flat bright disc about 330 px wide with a dark outline and a hard dark shadow pops in and wanders over the title along a looping path for 2.5 s; inside the disc the letters show in full: white fill (bright on the last line), thick dark outline, hard dark shadow. Then the disc grows fast past the edges of the frame and fades, leaving the whole title in full. Fades out at the end. light background or over the video.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
