# Tape Ticker Title

Section: 1.3 Animated titles
Video: Tape Ticker Title.mp4 (4 seconds, no sound)

## What it does
Two crossed sticker tapes shoot across the whole frame, one bright and one coloured; the title runs along them in opposite directions with turning sparkles in between. Text: the first line for the bright tape, the second for the coloured one. Option: speed

## Best used when
Breaking news, a launch, a warning or a sale: "new release", "just dropped"

## Prompt to make it from scratch
An animated title made with code for a 1080 x 1920 reel: two flat tapes 160 px high cross the full width of the frame, a bright one tilted 6 degrees up to the right and, just under it, a coloured one tilted 5 degrees the other way, each with a dark line along both edges and a hard dark shadow below. The bright tape shoots in from the left, the coloured one from the right a moment later. Along each tape the title repeats in chunky rounded dark capitals with a turning four-point sparkle between the repeats (bright on the bright tape, white on the coloured one, dark outline); the text on the bright tape runs to the left, on the coloured tape to the right, without stopping. Fades out at the end..

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
