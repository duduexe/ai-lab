# Shrink To Dot

Section: 1.3 Animated titles
Video: Shrink To Dot.mp4 (4 seconds, no sound)

## What it does
Text shrinks into a dot and disappears

## Best used when
An idea is dismissed or disappears ("forget that")

## Prompt to make it from scratch
An animated title for a 1080 x 1920 reel: Text shrinks into a dot and disappears. Brand fonts, pops in and fades out, inside the safe zone.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
