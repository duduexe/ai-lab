# Pixel Decode Title

Section: 1.3 Animated titles
Video: Pixel Decode Title.mp4 (4 seconds, no sound)

## What it does
Every letter starts as a blinking pixel block with a wrong sign on it, then pops into the real sticker letter, one after the other; a line of small bright pixels builds underneath. Text: up to 3 lines. Option: speed

## Best used when
A reveal with a tech or AI feel: a result, a secret, "the answer is"

## Prompt to make it from scratch
An animated title made with code for a 1080 x 1920 reel: each letter of a short headline first shows as a flat square block (bright, coloured or white in turn, 4 px dark outline, hard dark shadow) with a random letter or digit in a pixel font that changes about ten times a second. One after the other, every 0.11 s, a block shrinks away and the real letter pops out with a bounce: chunky rounded capitals, white fill (bright on the last line), thick dark outline and a hard dark shadow. When all letters are there, a row of small bright squares with a dark outline builds under the title, square by square. Fades out at the end. light background or over the video.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
