# Domino Title

Section: 1.3 Animated titles
Video: Domino Title.mp4 (4 seconds, no sound)

## What it does
Sticker letters stand in a row, fall onto each other like dominoes, are stopped by the last (bright) letter and get back up one by one; it repeats while the title stays. Text: one short line. Option: speed

## Best used when
One thing leads to the next: a chain reaction, steps that follow each other, "and then everything changed"

## Prompt to make it from scratch
An animated title made with code for a 1080 x 1920 reel: one line of chunky rounded sticker letters (white fill, thick dark outline, hard dark shadow; the last letter bright) pops in letter by letter. After a second the first letter tips over to the right around its bottom right corner and knocks the next one, and so on down the row, 0.1 s apart, each leaning about 50 degrees on its neighbour; the last letter only wobbles a little and holds. After a short pause the letters stand up again one by one from the far end, each with a springy overshoot. The cycle repeats. Fades out at the end. light background or over the video.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
