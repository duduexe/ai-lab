# Bar Chart

Section: 4.1 Charts and numbers
Video: Bar Chart.mp4 (4 seconds, no sound)

## What it does
Bars grow in

## Best used when
Comparing a few numbers

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Bars grow in. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
