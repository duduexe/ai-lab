# Big Number

Section: 4.1 Charts and numbers
Video: Big Number.mp4 (4 seconds, no sound)

## What it does
Number counts up, label underneath. Option: the number in the title font at a set size with a dark edge (font, size, outline)

## Best used when
One number is the point (a price, a time, a result)

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Number counts up, label underneath. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
