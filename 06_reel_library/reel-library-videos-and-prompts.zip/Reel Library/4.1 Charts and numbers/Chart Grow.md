# Chart Grow

Section: 4.1 Charts and numbers
Video: Chart Grow.mp4 (4 seconds, no sound)

## What it does
Bars bounce up one after the other out of the bottom left (the last one bright), their numbers count up, a bright arrow draws over the tops and a bright "+N%" pill pops

## Best used when
Growth: views, money, results going up

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Bars bounce up one after the other out of the bottom left (the last one bright), their numbers count up, a bright arrow draws over the tops and a bright "+N%" pill pops. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
