# Pie Chart

Section: 4.1 Charts and numbers
Video: Pie Chart.mp4 (4 seconds, no sound)

## What it does
Slices sweep in

## Best used when
Showing parts of a whole

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Slices sweep in. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
