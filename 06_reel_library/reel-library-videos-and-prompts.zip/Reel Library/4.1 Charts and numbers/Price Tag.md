# Price Tag

Section: 4.1 Charts and numbers
Video: Price Tag.mp4 (4 seconds, no sound)

## What it does
A bright price tag on a string swings in, the price counts up, or gets crossed out and flips over to a bright FREE side

## Best used when
A price, a saving or "it is free"

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: a bright price tag on a string swings in, the price counts up, or gets crossed out and flips over to a bright FREE side; text "price\. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
