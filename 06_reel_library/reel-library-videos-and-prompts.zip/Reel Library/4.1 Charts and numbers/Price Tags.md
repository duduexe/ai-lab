# Price Tags

Section: 4.1 Charts and numbers
Video: Price Tags.mp4 (4 seconds, no sound)

## What it does
Two price tags pop next to you

## Best used when
Comparing two prices

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Two price tags pop next to you. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
