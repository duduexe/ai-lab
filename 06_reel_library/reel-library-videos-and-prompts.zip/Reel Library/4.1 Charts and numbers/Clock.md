# Clock

Section: 4.1 Charts and numbers
Video: Clock.mp4 (4 seconds, no sound)

## What it does
A clock whose hand sweeps round and fills a bright slice, with a handwritten time next to it

## Best used when
Time spent or time saved

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A clock whose hand sweeps round and fills a bright slice, with a handwritten time next to it. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
