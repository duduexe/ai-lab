# Calendar

Section: 4.1 Charts and numbers
Video: Calendar.mp4 (4 seconds, no sound)

## What it does
A month calendar: days get ticked one after another; one day can get a hand-drawn circle and a handwritten note

## Best used when
Days, a plan or a streak

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A month calendar: days get ticked one after another; one day can get a hand-drawn circle and a handwritten note. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
