# Arguing Stickers

Section: 4.7 Characters, reactions and moments
Video: Arguing Stickers.mp4 (4 seconds, no sound)

## What it does
Two flat sticker characters arguing

## Best used when
A disagreement or two opinions

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Two flat sticker characters arguing. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
