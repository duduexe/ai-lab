# Hearts Up

Section: 4.7 Characters, reactions and moments
Video: Hearts Up.mp4 (4 seconds, no sound)

## What it does
Hearts floating up from a point

## Best used when
Love, likes or a sweet moment

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Hearts floating up from a point. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
