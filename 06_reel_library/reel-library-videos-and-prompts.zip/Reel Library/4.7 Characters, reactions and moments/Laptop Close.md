# Laptop Close

Section: 4.7 Characters, reactions and moments
Video: Laptop Close.mp4 (4 seconds, no sound)

## What it does
A laptop whose lid snaps shut, then "zzz"

## Best used when
Stopping work, the end of the day

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A laptop whose lid snaps shut, then "zzz". Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
