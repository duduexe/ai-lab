# Animated emoji

Section: 4.7 Characters, reactions and moments
Video: Animated emoji.mp4 (4 seconds, no sound)

## What it does
A big animated emoji pops in near your head and plays its little animation, then lifts away; ready: fire, laughing, heart, eyes, party, mind blown

## Best used when
A quick reaction: something is hot, funny, lovely, surprising or a win

## Prompt to make it from scratch
A Lottie animated emoji (Google Noto, CC BY 4.0, credit it) about 360 px wide, placed near the speaker's head on the left side, popping in (0.4 s), playing its loop and lifting away at the end; one emoji per moment.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
