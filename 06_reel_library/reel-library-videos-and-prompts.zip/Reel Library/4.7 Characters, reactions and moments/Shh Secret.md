# Shh Secret

Section: 4.7 Characters, reactions and moments
Video: Shh Secret.mp4 (4 seconds, no sound)

## What it does
A round coloured face puts a finger on its lips, winks, and a bright "shh" puffs out

## Best used when
A secret or a tip

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A round coloured face puts a finger on its lips, winks, and a bright "shh" puffs out. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
