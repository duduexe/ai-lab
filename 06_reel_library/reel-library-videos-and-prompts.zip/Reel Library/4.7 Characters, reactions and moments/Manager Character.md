# Manager Character

Section: 4.7 Characters, reactions and moments
Video: Manager Character.mp4 (4 seconds, no sound)

## What it does
A friendly manager character with a crown and a clipboard

## Best used when
A coordinator or a boss figure

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A friendly manager character with a crown and a clipboard. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
