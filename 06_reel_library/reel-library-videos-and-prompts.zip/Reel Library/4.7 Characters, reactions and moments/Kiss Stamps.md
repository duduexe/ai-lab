# Kiss Stamps

Section: 4.7 Characters, reactions and moments
Video: Kiss Stamps.mp4 (4 seconds, no sound)

## What it does
Two flat coloured kiss stamps with a dark outline that draws itself, little bright smack lines and a bright sparkle, no pink, no hearts. Option: the pink version with lipstick marks and floating hearts; the cleaner version above has no pink and no hearts

## Best used when
A cute kiss or "chef's kiss" moment

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: The cleaner version of Kiss Out: two flat coloured kiss stamps with a dark outline that draws itself, little bright smack lines and a bright sparkle, no pink, no hearts. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons). Option: the pink version with lipstick marks and floating hearts; the cleaner version above has no pink and no hearts.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
