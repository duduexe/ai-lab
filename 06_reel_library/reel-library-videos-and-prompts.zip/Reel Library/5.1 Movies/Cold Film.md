# Cold Film

Section: 5.1 Movies
Video: Cold Film.mp4 (4 seconds, no sound)

## What it does
Cool, muted colours, faded blacks

## Best used when
A cool, serious or winter mood

## Prompt to make it from scratch
A colour filter for talking-head footage: cool, muted colours, faded blacks. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
