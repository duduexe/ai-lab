# Low Lamp

Section: 5.1 Movies
Video: Low Lamp.mp4 (4 seconds, no sound)

## What it does
Darker, muted colours

## Best used when
A calm evening mood

## Prompt to make it from scratch
A colour filter for talking-head footage: darker, muted colours. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
