# Green and Ember

Section: 5.1 Movies
Video: Green and Ember.mp4 (4 seconds, no sound)

## What it does
Rich colours, punchy contrast

## Best used when
Punchy travel or lifestyle clips

## Prompt to make it from scratch
A colour filter for talking-head footage: rich colours, punchy contrast. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
