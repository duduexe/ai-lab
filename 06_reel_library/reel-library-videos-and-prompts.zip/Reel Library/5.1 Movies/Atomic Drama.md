# Atomic Drama

Section: 5.1 Movies
Video: Atomic Drama.mp4 (4 seconds, no sound)

## What it does
Muted colours, punchy contrast, film grain

## Best used when
A dramatic, serious story

## Prompt to make it from scratch
A colour filter for talking-head footage: muted colours, punchy contrast, film grain. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
