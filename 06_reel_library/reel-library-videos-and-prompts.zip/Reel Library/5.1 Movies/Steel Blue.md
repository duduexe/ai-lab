# Steel Blue

Section: 5.1 Movies
Video: Steel Blue.mp4 (4 seconds, no sound)

## What it does
Cool, muted colours

## Best used when
Tech or business topics

## Prompt to make it from scratch
A colour filter for talking-head footage: cool, muted colours. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
