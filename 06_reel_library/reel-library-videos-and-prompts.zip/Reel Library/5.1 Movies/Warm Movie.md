# Warm Movie

Section: 5.1 Movies
Video: Warm Movie.mp4 (4 seconds, no sound)

## What it does
Warm, darker, dark edges

## Best used when
A warm, cinematic talking head

## Prompt to make it from scratch
A colour filter for talking-head footage: warm, darker, dark edges. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
