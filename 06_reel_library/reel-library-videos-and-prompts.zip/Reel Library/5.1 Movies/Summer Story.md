# Summer Story

Section: 5.1 Movies
Video: Summer Story.mp4 (4 seconds, no sound)

## What it does
Warm, rich colours

## Best used when
Holidays and happy moments

## Prompt to make it from scratch
A colour filter for talking-head footage: warm, rich colours. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
