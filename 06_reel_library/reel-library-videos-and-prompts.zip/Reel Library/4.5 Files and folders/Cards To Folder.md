# Cards To Folder

Section: 4.5 Files and folders
Video: Cards To Folder.mp4 (4 seconds, no sound)

## What it does
Messy cards (your stills, photo and sound icons) float around your head, then fly into a folder and its name types in

## Best used when
Tidying messy things into one place

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Messy cards (your stills, photo and sound icons) float around your head, then fly into a folder and its name types in. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
