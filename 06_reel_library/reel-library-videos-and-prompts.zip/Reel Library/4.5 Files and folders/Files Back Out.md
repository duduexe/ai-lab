# Files Back Out

Section: 4.5 Files and folders
Video: Files Back Out.mp4 (4 seconds, no sound)

## What it does
The reverse of Cards to folder: the sorted folder pops in, shakes, tips open and the file cards (your pictures, photo icons, sound waves) shoot back out and land scattered around your head

## Best used when
A mess coming back

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: The reverse of Cards to folder: the sorted folder pops in, shakes, tips open and the file cards (your pictures, photo icons, sound waves) shoot back out and land scattered around your head. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
