# File Tree

Section: 4.5 Files and folders
Video: File Tree.mp4 (4 seconds, no sound)

## What it does
A folder tree in the split screen panel; groups of file cards fly along a curve into their folder, which lights up bright with a count; folders VIDEOS, SOUNDS and PICTURES

## Best used when
Sorting files into folders

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A folder tree in the split screen panel; groups of file cards fly along a curve into their folder, which lights up bright with a count; folders VIDEOS, SOUNDS and PICTURES. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
