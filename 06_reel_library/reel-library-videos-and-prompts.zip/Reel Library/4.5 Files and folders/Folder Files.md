# Folder Files

Section: 4.5 Files and folders
Video: Folder Files.mp4 (4 seconds, no sound)

## What it does
A folder: documents slide down into it one by one, then the folder name types in

## Best used when
Files going into a folder

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A folder: documents slide down into it one by one, then the folder name types in. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
