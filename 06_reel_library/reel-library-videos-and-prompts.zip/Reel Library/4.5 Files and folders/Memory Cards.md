# Memory Cards

Section: 4.5 Files and folders
Video: Memory Cards.mp4 (4 seconds, no sound)

## What it does
Memory cards drop in one by one on the words

## Best used when
Things to remember

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Memory cards drop in one by one on the words. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
