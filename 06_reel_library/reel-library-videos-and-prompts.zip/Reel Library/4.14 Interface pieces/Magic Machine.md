# Magic Machine

Section: 4.14 Interface pieces
Video: Magic Machine.mp4 (4 seconds, no sound)

## What it does
Plain white pages drop one by one into a small machine; it shakes, its sparkle spins, a lamp lights up, and each page comes out below as a colourful result card (a chart, a picture, a checklist). The three results line up as a fan. Options: label (the word on the machine), speed

## Best used when
You show that a tool or an AI turns something plain (notes, files, a prompt) into finished results

## Prompt to make it from scratch
A motion graphic made with code for a 1080 x 1920 reel: in the upper middle a flat sticker machine: a window with a bright title bar (three small squares and the word MAGIC in a pixel font), a coloured body with three small lamps on the left, a white round lens in the middle holding a bright four-point sparkle, a small gauge on the right, a coloured funnel on top and a coloured chute below; 4 px dark outlines and hard dark shadows with no blur. Three plain white pages with pale coloured text lines fall from the top one after the other, a little tilted, into the funnel. Each time the machine squashes and shakes, the sparkle spins faster, small bright and bright sparkles pop around it, a lamp turns bright, and a colourful card slides out of the chute with a bounce: first a bright card with a bar chart, then a coloured card with a sun and a wave, then a bright card with a checklist, each with its name in a pixel font on a white strip. The three cards land side by side below the machine as a slight fan and hop once together. light background.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
