# Option Roller

Section: 4.14 Interface pieces
Video: Option Roller.mp4 (4 seconds, no sound)

## What it does
A window with a roll of option stickers that clicks from one option to the next; the one in the middle turns bright between two arrows. With a pick it spins fast, slows down, stops on your option and a tick pops on. Options: pick (a name or a number), title, speed

## Best used when
You choose between a few things (which model, which tool, which plan) and want to show the choice being made

## Prompt to make it from scratch
A motion graphic made with code for a 1080 x 1920 reel: a flat sticker window (bright title bar with three small squares and the words PICK ONE in a pixel font, white body, 4 px dark outline, hard dark shadow with no blur). Inside, a vertical roll of pill-shaped option stickers (white, dark outline and pixel text, small hard shadow). Every second the roll clicks one place up with a small bounce; the option in the middle is bigger and bright, between two dark arrow heads that point at it, and the options above and below fade towards the edges of the window. Ending version: the roll spins fast, slows down and stops on one option, the window shadow turns bright and a round bright sticker with a tick pops in next to the picked option. light background.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
