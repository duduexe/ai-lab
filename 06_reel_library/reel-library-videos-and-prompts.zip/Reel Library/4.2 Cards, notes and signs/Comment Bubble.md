# Comment Bubble

Section: 4.2 Cards, notes and signs
Video: Comment Bubble.mp4 (4 seconds, no sound)

## What it does
A viewer comment card pops in and gets a heart. Option Instagram comment with an answer: laid out like the comments of an Instagram reel on frosted glass: round picture, user name and time, the comment typing in, "Reply", the heart and its count on the right lined up with the comment (the heart fills bright); then your answer comes in under it, indented, with your picture, your name and a small link card (added

## Best used when
Answering or quoting a viewer comment

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A viewer comment card pops in and gets a heart. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
