# Paper Note

Section: 4.2 Cards, notes and signs
Video: Paper Note.mp4 (4 seconds, no sound)

## What it does
A torn sheet of lined paper; handwritten lines write themselves from left to right

## Best used when
A handwritten note, a tip or a list

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A torn sheet of lined paper; handwritten lines write themselves from left to right. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
