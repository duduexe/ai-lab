# Spiral Stairs

Section: 4.2 Cards, notes and signs
Video: Spiral Stairs.mp4 (4 seconds, no sound)

## What it does
Pictures climb a spiral staircase around a dark pole, always facing you; the ones passing behind the pole are paler. Options: images, frame, speed, direction

## Best used when
A long list or a timeline of pictures that keeps going (history, versions, a growing collection)

## Prompt to make it from scratch
A looping motion graphic made with code for a 1080 x 1920 reel: flat sticker window cards wind around a thin vertical dark pole like the steps of a spiral staircase and climb without stopping. The cards always face the viewer; those behind the pole are washed pale and hidden by it where they cross. Each card: bright title bar, picture, 4 px dark outline, hard dark shadow. light background.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
