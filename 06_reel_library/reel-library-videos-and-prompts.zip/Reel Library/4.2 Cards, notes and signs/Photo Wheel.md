# Photo Wheel

Section: 4.2 Cards, notes and signs
Video: Photo Wheel.mp4 (4 seconds, no sound)

## What it does
A big fairground wheel of upright pictures with spokes and a bright hub; it clicks round and the picture at the top is the one in focus. Options: images, frame, speed, direction

## Best used when
A playful run through many pictures, for example "everything I tried this week"

## Prompt to make it from scratch
A looping motion graphic made with code for a 1080 x 1920 reel: a flat fairground wheel whose centre is in the lower half of the frame: ten dark spokes, a bright hub with a bright four-point sparkle, and ten flat sticker cards at the spoke ends that stay almost upright. Every second the wheel clicks one place with a small bounce; the card at the top is 1.25 times bigger with a bright shadow, the others smaller and slightly pale. light background.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
