# Item delivery prop

Section: 4.2 Cards, notes and signs
Video: Item delivery prop.mp4 (4 seconds, no sound)

## What it does
Delivers your pictures or lines with a prop: framed photos riding a conveyor belt (default), photos hanging on a clothesline with pegs, a receipt printing out line by line, or an envelope that drops in, opens and pours out photo cards

## Best used when
Showing several examples, results or steps one after the other in a playful way

## Prompt to make it from scratch
A graphic animation for a 1080 x 1920 reel that works over any video, with a prop option: "conveyor" (white-framed photo cards ride a dark belt with turning rollers), "clothesline" (cards slide in and hang from bright pegs on a sagging line, swaying), "receipt" (a dark printer feeds out a zig-zag paper and the lines of text appear one at a time, the last line bright) or "envelope" (a coloured envelope drops in above the head, the flap opens and cards pour out into a fan); images = the pictures.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
