# Film Strip

Section: 4.2 Cards, notes and signs
Video: Film Strip.mp4 (4 seconds, no sound)

## What it does
A dark film strip with sprocket holes runs through the frame and sways like a ribbon; each frame holds a picture with its name and number. Options: images, speed, direction

## Best used when
Behind-the-scenes, clips, "footage" or anything about filming and editing

## Prompt to make it from scratch
A looping motion graphic made with code for a 1080 x 1920 reel: one vertical film strip in dark, 540 px wide, tilted 5 degrees, with light sprocket holes down both edges. It runs upwards without stopping and sways left and right like a ribbon. Each frame of the strip holds a picture with rounded corners and a coloured outline, and below it a name in a pixel font on the left and a bright frame number on the right. light background.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
