# Dealer Cards

Section: 4.2 Cards, notes and signs
Video: Dealer Cards.mp4 (4 seconds, no sound)

## What it does
A row of overlapping dark cards with a circled number is dealt in from the left, then the cards turn over one by one like a dealer revealing them: each lifts and flips in 3D and shows a light card with a bright number, a big title and a small caption. Option spread: a 6th label number sets how far apart the cards sit (0.62 = overlapping, 1.08 = side by side) (added

## Best used when
Revealing a list of steps, parts or features one at a time while talking

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: 2 to 6 cards 300 px wide, 420 px tall, rounded, tilted a little in a fan, overlapping and squeezed between x 70 and x 887 so nothing sits under the app buttons (lower part of the safe zone, top at y 1090); dealt in from the left with a small spin and bounce (0.1 s apart); from 0.9 s each card turns over every 0.7 s (3D flip about 0.6 s, lifts 46 px and grows 9 percent, then settles with a small bounce, bright sparkle on the corner); back: dark gradient with a coloured circled number (a small pixel-style label font); front: light pale with a dark outline, bright number pill (a small pixel-style label font), title in a bold rounded title font, caption in a small pixel-style label font capitals; fades out in the last 0.35 s.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
