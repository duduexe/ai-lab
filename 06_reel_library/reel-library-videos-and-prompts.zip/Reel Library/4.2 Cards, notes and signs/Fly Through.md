# Fly Through

Section: 4.2 Cards, notes and signs
Video: Fly Through.mp4 (4 seconds, no sound)

## What it does
You fly forward through pictures hanging left and right, each a little crooked; far ones are pale, near ones grow and pass by. Options: images, frame, speed, direction

## Best used when
A fast "so many things happened" moment, or travelling through memories or releases

## Prompt to make it from scratch
A looping motion graphic made with code for a 1080 x 1920 reel: the camera flies straight forward through twelve flat sticker window cards hanging in 3D space, left and right in turn and at three heights, each tilted a few degrees like a sticker put on by hand. Far cards are small and washed pale, near cards grow, pass the camera and fade. Each card: bright title bar, picture, 4 px dark outline, hard dark shadow. light background.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
