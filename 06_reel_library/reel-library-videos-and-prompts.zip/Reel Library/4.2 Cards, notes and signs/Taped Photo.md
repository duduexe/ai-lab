# Taped Photo

Section: 4.2 Cards, notes and signs
Video: Taped Photo.mp4 (4 seconds, no sound)

## What it does
A photo or clip in a light paper frame drops in, then a strip of tape lands on top

## Best used when
A photo or screenshot as a souvenir

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A photo or clip in a light paper frame drops in, then a strip of tape lands on top. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
