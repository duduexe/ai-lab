# File Card

Section: 4.2 Cards, notes and signs
Video: File Card.mp4 (4 seconds, no sound)

## What it does
A notes card that looks like a text file: a small label with the file name at the top, a dashed coloured border, and lines of text that type in

## Best used when
A file, a note or a prompt you saved

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A notes card that looks like a text file: a small label with the file name at the top, a dashed coloured border, and lines of text that type in. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
