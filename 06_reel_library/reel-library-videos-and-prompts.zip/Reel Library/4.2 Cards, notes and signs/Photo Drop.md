# Photo Drop

Section: 4.2 Cards, notes and signs
Video: Photo Drop.mp4 (4 seconds, no sound)

## What it does
Instant photos with a handwritten name drop from the top one by one and land in a loose pile with a bounce; the newest one has the bright shadow. Options: images, frame, speed

## Best used when
Memories, a recap or "look at all these" where the pictures should pile up

## Prompt to make it from scratch
A motion graphic made with code for a 1080 x 1920 reel: eight instant photos (white frame with a wide bottom edge and a handwritten name, 4 px dark outline, hard dark shadow) fall from above the frame one after the other, every 0.3 s, spinning a little, and land with a bounce in a loose pile around the middle, each at its own angle. The newest photo has a bright shadow. light background.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
