# Coming Soon Sign

Section: 4.2 Cards, notes and signs
Video: Coming Soon Sign.mp4 (4 seconds, no sound)

## What it does
A shop door sign drops in on a string, swings and settles, then swings away. Option glass: a frosted glass sign swings down on two strings, its text big (a small pixel-style label font 64, two lines when long); the small gift boxes were removed (added

## Best used when
Teasing what comes next

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A shop door sign drops in on a string, swings and settles, then swings away (text "small. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
