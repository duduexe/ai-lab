# Carousel Ring

Section: 4.2 Cards, notes and signs
Video: Carousel Ring.mp4 (4 seconds, no sound)

## What it does
Window cards ride a round turntable seen a little from above; they always face you, and the ring clicks round one place per beat, the cards at the back paler. Options: images, frame, speed, direction

## Best used when
You show a set of things that belong together (tools, steps, examples) and none is more important than the others

## Prompt to make it from scratch
A looping motion graphic made with code for a 1080 x 1920 reel: seven flat sticker window cards (bright title bar, picture, 4 px dark outline, hard dark shadow) stand on a coloured turntable disc with a dark outline, seen slightly from above in 3D. The cards always face the viewer. Every second the ring turns one place with a small bounce; the front card has a bright shadow, the back cards are washed pale. light background.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
