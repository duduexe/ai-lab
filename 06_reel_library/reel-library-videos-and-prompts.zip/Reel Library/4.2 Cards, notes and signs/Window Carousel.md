# Window Carousel

Section: 4.2 Cards, notes and signs
Video: Window Carousel.mp4 (4 seconds, no sound)

## What it does
A row of retro window cards; each beat the next one clicks into the middle, bigger and straight, with a bright shadow, while small squares below show which one is on. Options: images, frame (window, photo, plain), speed, direction

## Best used when
You go through several pictures or screenshots one by one, and each should have its moment

## Prompt to make it from scratch
A looping motion graphic made with code for a 1080 x 1920 reel: seven flat sticker cards in a row, each a retro window (bright title bar with three small squares and a name, picture below, 4 px dark outline, hard 8 px dark shadow with no blur). Every 1.2 s the row clicks one place to the left with a small bounce; the middle card is 1.2 times bigger and straight with a bright shadow, the side cards are smaller, tilted 5 degrees and slightly faded. A row of seven small outlined squares below, the active one bright. light background.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
