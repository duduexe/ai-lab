# Tilted Wall

Section: 4.2 Cards, notes and signs
Video: Tilted Wall.mp4 (4 seconds, no sound)

## What it does
A slanted wall of pictures that fills the frame; its four columns run up and down in turn, like conveyor belts. Options: images, frame, speed, direction

## Best used when
A busy full-frame background of pictures behind a big title or your cut-out

## Prompt to make it from scratch
A looping motion graphic made with code for a 1080 x 1920 reel: a flat wall of sticker window cards in four columns, the whole wall tilted 10 degrees. Columns one and three run slowly upwards, columns two and four downwards, without stopping, and the wall fills the whole frame. Each card: bright title bar, picture, 4 px dark outline, hard dark shadow. light background.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
