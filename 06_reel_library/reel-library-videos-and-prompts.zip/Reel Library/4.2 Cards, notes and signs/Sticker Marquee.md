# Sticker Marquee

Section: 4.2 Cards, notes and signs
Video: Sticker Marquee.mp4 (4 seconds, no sound)

## What it does
Slanted rows of name stickers and small pictures run past each other, left and right in turn. Options: images, speed, direction

## Best used when
A list of names, tools or topics should feel like a lot, behind a title or as a break

## Prompt to make it from scratch
A looping motion graphic made with code for a 1080 x 1920 reel: six rows tilted 8 degrees fill the frame. In each row pill-shaped name stickers (bright, white, coloured or bright, 4 px dark outline, hard dark shadow, name in a dark pixel font, capitals) alternate with small square pictures with the same outline and shadow. Rows run left and right in turn at slightly different speeds, without stopping. light background.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
