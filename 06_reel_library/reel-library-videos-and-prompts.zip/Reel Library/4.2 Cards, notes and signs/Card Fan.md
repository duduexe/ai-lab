# Card Fan

Section: 4.2 Cards, notes and signs
Video: Card Fan.mp4 (4 seconds, no sound)

## What it does
A hand of cards: the deck pops in, fans open, then one card after the other is pulled up, straightened and shown with a bright shadow. Options: images, frame, speed

## Best used when
You present three to five options, picks or examples and name them one by one

## Prompt to make it from scratch
A motion graphic made with code for a 1080 x 1920 reel: five flat sticker window cards pop in as one deck, then fan open like a hand of playing cards (about 10 degrees between cards, pivot far below) with a bounce. Then every 0.8 s one card, from left to right, is pulled up out of the fan, straightens, grows a little and gets a bright shadow, then slides back. Each card: bright title bar, picture, 4 px dark outline, hard dark shadow. light background.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
