# Curved Wall

Section: 4.2 Cards, notes and signs
Video: Curved Wall.mp4 (4 seconds, no sound)

## What it does
Two rows of pictures on a wall that curves around you; the rows glide slowly in opposite directions. Options: images, frame, speed, direction

## Best used when
You want to show "there are a lot of them" calmly, behind a title or a voice-over

## Prompt to make it from scratch
A looping motion graphic made with code for a 1080 x 1920 reel: sixteen flat sticker window cards in two rows on the inside of a wide curved wall in 3D (the middle is far, the sides come towards the viewer and turn inwards). The top row glides slowly one way, the bottom row the other way, without stopping. Each card: bright title bar, picture, 4 px dark outline, hard dark shadow. light background.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
