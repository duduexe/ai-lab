# Spotlight Grid

Section: 4.2 Cards, notes and signs
Video: Spotlight Grid.mp4 (4 seconds, no sound)

## What it does
A grid of twelve pale pictures; one after the other jumps forward in full colour with a bright shadow, then sinks back. Options: images, frame, speed

## Best used when
An overview where single items get picked out (a team, a tool list, results)

## Prompt to make it from scratch
A looping motion graphic made with code for a 1080 x 1920 reel: twelve flat sticker window cards in a grid of three columns and four rows, all washed pale. Every 0.75 s one card, in a mixed order, jumps forward with a bounce: full colour, 1.3 times bigger, tilted 3 degrees, bright shadow; then it sinks back and the next one jumps. Each card: bright title bar, picture, 4 px dark outline, hard dark shadow. light background.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
