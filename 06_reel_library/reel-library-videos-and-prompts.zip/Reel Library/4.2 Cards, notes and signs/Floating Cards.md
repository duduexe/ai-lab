# Floating Cards

Section: 4.2 Cards, notes and signs
Video: Floating Cards.mp4 (4 seconds, no sound)

## What it does
Cards with screenshots or clips fan out from the middle and keep floating gently

## Best used when
Several screenshots or examples

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Cards with screenshots or clips fan out from the middle and keep floating gently. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
