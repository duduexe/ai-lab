# Round reveal out

Section: 2.2 Standard transitions
Video: Round reveal out.mp4 (4 seconds, no sound)

## What it does
Closes as a soft round shape to the middle

## Best used when
A clip, picture or graphic should leave this way: closes as a soft round shape to the middle

## Prompt to make it from scratch
An out transition for any clip, picture or graphic: Closes as a soft round shape to the middle. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
