# Fade to black

Section: 2.2 Standard transitions
Video: Fade to black.mp4 (4 seconds, no sound)

## What it does
The picture darkens to black

## Best used when
A clip, picture or graphic should leave this way: the picture darkens to black

## Prompt to make it from scratch
An out transition for any clip, picture or graphic: The picture darkens to black. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
