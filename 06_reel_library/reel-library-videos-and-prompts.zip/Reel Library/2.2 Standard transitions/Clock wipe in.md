# Clock wipe in

Section: 2.2 Standard transitions
Video: Clock wipe in.mp4 (4 seconds, no sound)

## What it does
A wedge sweeps round the middle like a clock hand and uncovers the clip

## Best used when
Time passing, or the next step of a routine

## Prompt to make it from scratch
An in transition: a wedge sweeps clockwise round the middle like a clock hand and uncovers the clip, about 0.7 s. Works on any clip, picture or graphic, no drawn extras on the footage.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
