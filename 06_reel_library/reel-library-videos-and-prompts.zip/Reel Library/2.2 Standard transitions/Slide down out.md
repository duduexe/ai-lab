# Slide down out

Section: 2.2 Standard transitions
Video: Slide down out.mp4 (4 seconds, no sound)

## What it does
Slides away downwards

## Best used when
A clip, picture or graphic should leave this way: slides away downwards

## Prompt to make it from scratch
An out transition for any clip, picture or graphic: Slides away downwards. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
