# Zoom blur out

Section: 2.2 Standard transitions
Video: Zoom blur out.mp4 (4 seconds, no sound)

## What it does
Zooms in hard, blurs and turns a little as it leaves

## Best used when
Rushing out of one idea into the next

## Prompt to make it from scratch
An out transition: the clip zooms in hard, blurs and turns a few degrees as it fades, about 0.5 s. Works on any clip, picture or graphic, no drawn extras on the footage.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
