# Flash out

Section: 2.2 Standard transitions
Video: Flash out.mp4 (4 seconds, no sound)

## What it does
Leaves in a white flash

## Best used when
A clip, picture or graphic should leave this way: leaves in a white flash

## Prompt to make it from scratch
An out transition for any clip, picture or graphic: Leaves in a white flash. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
