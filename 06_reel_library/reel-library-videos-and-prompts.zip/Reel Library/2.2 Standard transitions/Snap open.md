# Snap open

Section: 2.2 Standard transitions
Video: Snap open.mp4 (4 seconds, no sound)

## What it does
Opens from a small rounded box in the middle, a little bright

## Best used when
A clip, picture or graphic should come in this way: opens from a small rounded box in the middle, a little bright

## Prompt to make it from scratch
An in transition for any clip, picture or graphic: Opens from a small rounded box in the middle, a little bright. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
