# Find the signal

Section: 2.2 Standard transitions
Video: Find the signal.mp4 (4 seconds, no sound)

## What it does
Black, then static, then the picture gets clearer.

## Best used when
Tuning in to a new topic

## Prompt to make it from scratch
An in transition for any clip, picture or graphic: Black, then static, then the picture gets clearer. About 0.3 to 0.6 s, no drawn extras.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
