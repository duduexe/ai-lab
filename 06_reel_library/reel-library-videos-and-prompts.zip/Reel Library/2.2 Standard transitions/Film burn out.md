# Film burn out

Section: 2.2 Standard transitions
Video: Film burn out.mp4 (4 seconds, no sound)

## What it does
A flickering flame edge burns the clip away

## Best used when
Ending a part with a warm, nostalgic or dramatic feel

## Prompt to make it from scratch
An out transition: an uneven flickering flame edge (bright and white glow, dark scorch just behind) sweeps across on a diagonal and burns the clip away, about 0.8 s. Works on any clip, picture or graphic, no drawn extras on the footage.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
