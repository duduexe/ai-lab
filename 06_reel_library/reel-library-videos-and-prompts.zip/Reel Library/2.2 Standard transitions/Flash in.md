# Flash in

Section: 2.2 Standard transitions
Video: Flash in.mp4 (4 seconds, no sound)

## What it does
A white flash, then the picture

## Best used when
A clip, picture or graphic should come in this way: a white flash, then the picture

## Prompt to make it from scratch
An in transition for any clip, picture or graphic: A white flash, then the picture. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
