# Lose the signal

Section: 2.2 Standard transitions
Video: Lose the signal.mp4 (4 seconds, no sound)

## What it does
The picture gets lost in static, then goes black.

## Best used when
Cutting away from a topic or a fail

## Prompt to make it from scratch
An out transition for any clip, picture or graphic: The picture gets lost in static, then goes black. About 0.3 to 0.6 s, no drawn extras.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
