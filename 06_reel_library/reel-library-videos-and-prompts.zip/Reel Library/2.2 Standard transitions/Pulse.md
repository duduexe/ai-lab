# Pulse

Section: 2.2 Standard transitions
Video: Pulse.mp4 (4 seconds, no sound)

## What it does
Grows and shrinks gently the whole time

## Best used when
Something should keep moving while it stays: grows and shrinks gently the whole time

## Prompt to make it from scratch
A whole-time (combo) transition for any clip, picture or graphic: Grows and shrinks gently the whole time. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
