# Heart beat

Section: 2.2 Standard transitions
Video: Heart beat.mp4 (4 seconds, no sound)

## What it does
Two quick beats then a pause, like a heart

## Best used when
Something should keep moving while it stays: two quick beats then a pause, like a heart

## Prompt to make it from scratch
A whole-time (combo) transition for any clip, picture or graphic: Two quick beats then a pause, like a heart. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
