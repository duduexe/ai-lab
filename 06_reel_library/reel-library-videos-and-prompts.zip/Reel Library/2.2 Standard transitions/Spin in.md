# Spin in

Section: 2.2 Standard transitions
Video: Spin in.mp4 (4 seconds, no sound)

## What it does
Spins in from small (one turn)

## Best used when
A clip, picture or graphic should come in this way: spins in from small (one turn)

## Prompt to make it from scratch
An in transition for any clip, picture or graphic: Spins in from small (one turn). About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
