# Bounce

Section: 2.2 Standard transitions
Video: Bounce.mp4 (4 seconds, no sound)

## What it does
Bounces up and down the whole time

## Best used when
Something should keep moving while it stays: bounces up and down the whole time

## Prompt to make it from scratch
A whole-time (combo) transition for any clip, picture or graphic: Bounces up and down the whole time. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
