# Round reveal in

Section: 2.2 Standard transitions
Video: Round reveal in.mp4 (4 seconds, no sound)

## What it does
Opens as a soft round reveal from the middle

## Best used when
A clip, picture or graphic should come in this way: opens as a soft round reveal from the middle

## Prompt to make it from scratch
An in transition for any clip, picture or graphic: Opens as a soft round reveal from the middle. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
