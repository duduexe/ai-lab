# Blur fade in

Section: 2.2 Standard transitions
Video: Blur fade in.mp4 (4 seconds, no sound)

## What it does
Comes in blurred and sharpens

## Best used when
A clip, picture or graphic should come in this way: comes in blurred and sharpens

## Prompt to make it from scratch
An in transition for any clip, picture or graphic: Comes in blurred and sharpens. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
