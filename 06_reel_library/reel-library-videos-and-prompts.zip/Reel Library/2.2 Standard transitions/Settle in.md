# Settle in

Section: 2.2 Standard transitions
Video: Settle in.mp4 (4 seconds, no sound)

## What it does
Comes in slightly big and low, then settles into place

## Best used when
A clip, picture or graphic should come in this way: comes in slightly big and low, then settles into place

## Prompt to make it from scratch
An in transition for any clip, picture or graphic: Comes in slightly big and low, then settles into place. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
