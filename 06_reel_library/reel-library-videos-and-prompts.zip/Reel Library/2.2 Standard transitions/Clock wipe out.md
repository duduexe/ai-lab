# Clock wipe out

Section: 2.2 Standard transitions
Video: Clock wipe out.mp4 (4 seconds, no sound)

## What it does
A wedge sweeps round the middle and covers the clip

## Best used when
Time passing, or ending a step

## Prompt to make it from scratch
An out transition: a wedge sweeps round the middle like a clock hand and takes the clip away, about 0.7 s. Works on any clip, picture or graphic, no drawn extras on the footage.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
