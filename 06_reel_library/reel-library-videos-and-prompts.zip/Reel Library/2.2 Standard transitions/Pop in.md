# Pop in

Section: 2.2 Standard transitions
Video: Pop in.mp4 (4 seconds, no sound)

## What it does
Pops in from small with a quick bounce

## Best used when
A clip, picture or graphic should come in this way: pops in from small with a quick bounce

## Prompt to make it from scratch
An in transition for any clip, picture or graphic: Pops in from small with a quick bounce. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
