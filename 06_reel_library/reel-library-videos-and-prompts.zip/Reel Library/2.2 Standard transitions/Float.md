# Float

Section: 2.2 Standard transitions
Video: Float.mp4 (4 seconds, no sound)

## What it does
Floats gently up and down

## Best used when
Something should keep moving while it stays: floats gently up and down

## Prompt to make it from scratch
A whole-time (combo) transition for any clip, picture or graphic: Floats gently up and down. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
