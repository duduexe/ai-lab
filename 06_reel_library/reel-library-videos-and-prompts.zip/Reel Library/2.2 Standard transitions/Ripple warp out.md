# Ripple warp out

Section: 2.2 Standard transitions
Video: Ripple warp out.mp4 (4 seconds, no sound)

## What it does
The clip wobbles in growing waves as it fades away

## Best used when
Going into a dream, a memory or a flashback

## Prompt to make it from scratch
An out transition: the clip wobbles in smooth waves that grow while it fades away, about 0.8 s. Works on any clip, picture or graphic, no drawn extras on the footage.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
