# Book flip in

Section: 2.2 Standard transitions
Video: Book flip in.mp4 (4 seconds, no sound)

## What it does
The clip turns in like a page around its left edge, darker on the fold side

## Best used when
Turning to the next chapter or story part

## Prompt to make it from scratch
An in transition: the clip turns in like a book page around its left edge (from about 96 degrees to flat), darker on the fold side, about 0.7 s. Works on any clip, picture or graphic, no drawn extras on the footage.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
