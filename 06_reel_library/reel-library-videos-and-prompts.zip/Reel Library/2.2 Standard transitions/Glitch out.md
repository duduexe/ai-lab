# Glitch out

Section: 2.2 Standard transitions
Video: Glitch out.mp4 (4 seconds, no sound)

## What it does
Leaves with short glitch shifts and colour jitter

## Best used when
A clip, picture or graphic should leave this way: leaves with short glitch shifts and colour jitter

## Prompt to make it from scratch
An out transition for any clip, picture or graphic: Leaves with short glitch shifts and colour jitter. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
