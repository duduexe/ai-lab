# Venetian blinds in

Section: 2.2 Standard transitions
Video: Venetian blinds in.mp4 (4 seconds, no sound)

## What it does
The clip opens in horizontal strips, one after the other, like blinds

## Best used when
A clean, graphic reveal (a new section, a list item)

## Prompt to make it from scratch
An in transition: the clip is revealed in 10 horizontal strips that open one after the other from the top, like blinds, about 0.7 s. Works on any clip, picture or graphic, no drawn extras on the footage.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
