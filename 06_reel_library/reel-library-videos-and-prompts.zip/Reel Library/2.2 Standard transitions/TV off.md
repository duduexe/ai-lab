# TV off

Section: 2.2 Standard transitions
Video: TV off.mp4 (4 seconds, no sound)

## What it does
The picture closes to a bright line, then the line closes.

## Best used when
Ending a part or the video with a retro feel

## Prompt to make it from scratch
An out transition for any clip, picture or graphic: The picture closes to a bright line, then the line closes. About 0.3 to 0.6 s, no drawn extras.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
