# Slide down in

Section: 2.2 Standard transitions
Video: Slide down in.mp4 (4 seconds, no sound)

## What it does
Slides in from above

## Best used when
A clip, picture or graphic should come in this way: slides in from above

## Prompt to make it from scratch
An in transition for any clip, picture or graphic: Slides in from above. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
