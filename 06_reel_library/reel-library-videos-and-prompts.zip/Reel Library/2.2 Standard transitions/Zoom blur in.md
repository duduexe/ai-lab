# Zoom blur in

Section: 2.2 Standard transitions
Video: Zoom blur in.mp4 (4 seconds, no sound)

## What it does
Starts zoomed in, blurred and a little turned, then settles sharp

## Best used when
Jumping into a new idea with impact

## Prompt to make it from scratch
An in transition: the clip starts zoomed in about 2x, blurred and turned a few degrees, then zooms back to its size and gets sharp, about 0.5 s. Works on any clip, picture or graphic, no drawn extras on the footage.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
