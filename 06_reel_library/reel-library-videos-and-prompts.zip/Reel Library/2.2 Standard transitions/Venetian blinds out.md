# Venetian blinds out

Section: 2.2 Standard transitions
Video: Venetian blinds out.mp4 (4 seconds, no sound)

## What it does
The clip closes in horizontal strips, one after the other

## Best used when
A clean, graphic exit

## Prompt to make it from scratch
An out transition: the clip is hidden in 10 horizontal strips that close one after the other, like blinds, about 0.7 s. Works on any clip, picture or graphic, no drawn extras on the footage.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
