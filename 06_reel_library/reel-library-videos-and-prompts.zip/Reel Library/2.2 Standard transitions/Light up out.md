# Light up out

Section: 2.2 Standard transitions
Video: Light up out.mp4 (4 seconds, no sound)

## What it does
Gets very bright as it leaves

## Best used when
A clip, picture or graphic should leave this way: gets very bright as it leaves

## Prompt to make it from scratch
An out transition for any clip, picture or graphic: Gets very bright as it leaves. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
