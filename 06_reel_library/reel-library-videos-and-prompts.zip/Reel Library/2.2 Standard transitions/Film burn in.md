# Film burn in

Section: 2.2 Standard transitions
Video: Film burn in.mp4 (4 seconds, no sound)

## What it does
A flickering bright and white flame edge burns across from one side and reveals the clip

## Best used when
A warm, nostalgic or dramatic change, like old film burning

## Prompt to make it from scratch
An in transition: an uneven flickering flame edge (bright and white glow, dark scorch just behind) sweeps across the frame on a diagonal and reveals the clip; the footage keeps its colours, about 0.8 s. Works on any clip, picture or graphic, no drawn extras on the footage.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
