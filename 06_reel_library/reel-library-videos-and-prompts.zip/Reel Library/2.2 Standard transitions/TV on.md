# TV on

Section: 2.2 Standard transitions
Video: TV on.mp4 (4 seconds, no sound)

## What it does
A bright line opens from the middle of a black screen, then the picture opens from that line.

## Best used when
Opening a story, a "broadcast" or a retro moment

## Prompt to make it from scratch
An in transition for any clip, picture or graphic: A bright line opens from the middle of a black screen, then the picture opens from that line. About 0.3 to 0.6 s, no drawn extras.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
