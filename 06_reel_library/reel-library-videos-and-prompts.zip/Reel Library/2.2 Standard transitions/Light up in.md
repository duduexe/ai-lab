# Light up in

Section: 2.2 Standard transitions
Video: Light up in.mp4 (4 seconds, no sound)

## What it does
Comes in very bright and calms down to normal

## Best used when
A clip, picture or graphic should come in this way: comes in very bright and calms down to normal

## Prompt to make it from scratch
An in transition for any clip, picture or graphic: Comes in very bright and calms down to normal. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
