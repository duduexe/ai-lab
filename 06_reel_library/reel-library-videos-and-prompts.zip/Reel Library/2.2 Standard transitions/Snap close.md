# Snap close

Section: 2.2 Standard transitions
Video: Snap close.mp4 (4 seconds, no sound)

## What it does
Closes into a small rounded box in the middle

## Best used when
A clip, picture or graphic should leave this way: closes into a small rounded box in the middle

## Prompt to make it from scratch
An out transition for any clip, picture or graphic: Closes into a small rounded box in the middle. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
