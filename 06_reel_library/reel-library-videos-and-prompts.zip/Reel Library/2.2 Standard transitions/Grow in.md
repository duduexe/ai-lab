# Grow in

Section: 2.2 Standard transitions
Video: Grow in.mp4 (4 seconds, no sound)

## What it does
Grows in from small

## Best used when
A clip, picture or graphic should come in this way: grows in from small

## Prompt to make it from scratch
An in transition for any clip, picture or graphic: Grows in from small. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
