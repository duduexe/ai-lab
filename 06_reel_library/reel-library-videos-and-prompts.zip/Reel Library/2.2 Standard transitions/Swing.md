# Swing

Section: 2.2 Standard transitions
Video: Swing.mp4 (4 seconds, no sound)

## What it does
Swings left and right like on a string

## Best used when
Something should keep moving while it stays: swings left and right like on a string

## Prompt to make it from scratch
A whole-time (combo) transition for any clip, picture or graphic: Swings left and right like on a string. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
