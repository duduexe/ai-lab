# Wobble

Section: 2.2 Standard transitions
Video: Wobble.mp4 (4 seconds, no sound)

## What it does
Wobbles like jelly

## Best used when
Something should keep moving while it stays: wobbles like jelly

## Prompt to make it from scratch
A whole-time (combo) transition for any clip, picture or graphic: Wobbles like jelly. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
