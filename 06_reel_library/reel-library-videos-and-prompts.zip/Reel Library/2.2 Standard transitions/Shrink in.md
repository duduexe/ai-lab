# Shrink in

Section: 2.2 Standard transitions
Video: Shrink in.mp4 (4 seconds, no sound)

## What it does
Comes in big and shrinks to its size

## Best used when
A clip, picture or graphic should come in this way: comes in big and shrinks to its size

## Prompt to make it from scratch
An in transition for any clip, picture or graphic: Comes in big and shrinks to its size. About 0.3 to 0.6 s, no drawn extras.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
