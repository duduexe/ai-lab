# Whip pan out

Section: 2.2 Standard transitions
Video: Whip pan out.mp4 (4 seconds, no sound)

## What it does
Leaves very fast to the left with a strong horizontal motion blur

## Best used when
A fast, energetic change of scene, paired with Whip pan in on the next clip

## Prompt to make it from scratch
An out transition: the clip leaves to the left very fast with a strong horizontal motion blur that peaks in the middle of the move, about 0.4 to 0.5 s. Works on any clip, picture or graphic, no drawn extras on the footage.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
