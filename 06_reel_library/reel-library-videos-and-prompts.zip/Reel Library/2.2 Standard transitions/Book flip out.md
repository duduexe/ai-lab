# Book flip out

Section: 2.2 Standard transitions
Video: Book flip out.mp4 (4 seconds, no sound)

## What it does
The clip turns away like a page around its left edge

## Best used when
Ending a chapter or a story part

## Prompt to make it from scratch
An out transition: the clip turns away like a book page around its left edge, getting darker on the fold side, about 0.7 s. Works on any clip, picture or graphic, no drawn extras on the footage.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
