# Whip pan in

Section: 2.2 Standard transitions
Video: Whip pan in.mp4 (4 seconds, no sound)

## What it does
A very fast sideways move from the right with a strong horizontal motion blur that hides the cut

## Best used when
A fast, energetic change of scene, like the camera whipping round

## Prompt to make it from scratch
An in transition: the clip arrives from the right very fast with a strong horizontal motion blur that peaks in the middle of the move, about 0.4 to 0.5 s. Works on any clip, picture or graphic, no drawn extras on the footage.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
