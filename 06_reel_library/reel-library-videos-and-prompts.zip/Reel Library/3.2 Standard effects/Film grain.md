# Film grain

Section: 3.2 Standard effects
Video: Film grain.mp4 (4 seconds, no sound)

## What it does
Moving film grain. Settings: intensity, speed, fade

## Best used when
A filmic, less digital look

## Prompt to make it from scratch
A "Film grain" effect over a stretch of video: Moving film grain. Settings: intensity, speed, fade. Settings for intensity, speed and fade; the footage stays visible.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
