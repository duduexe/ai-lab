# Strobe

Section: 3.2 Standard effects
Video: Strobe.mp4 (4 seconds, no sound)

## What it does
Fast on and off white flashes. Settings: intensity, speed, fade

## Best used when
A party or very high-energy moment, use briefly

## Prompt to make it from scratch
A "Strobe" effect over a stretch of video: Fast on and off white flashes. Settings: intensity, speed, fade. Settings for intensity, speed and fade; the footage stays visible.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
