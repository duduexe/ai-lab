# Zoom beat

Section: 3.2 Standard effects
Video: Zoom beat.mp4 (4 seconds, no sound)

## What it does
Quick small zoom pulses in a rhythm. Settings: intensity, speed, fade

## Best used when
Music with a clear beat

## Prompt to make it from scratch
A "Zoom beat" effect over a stretch of video: Quick small zoom pulses in a rhythm. Settings: intensity, speed, fade. Settings for intensity, speed and fade; the footage stays visible.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
