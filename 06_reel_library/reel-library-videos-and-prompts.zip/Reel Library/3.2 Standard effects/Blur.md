# Blur

Section: 3.2 Standard effects
Video: Blur.mp4 (4 seconds, no sound)

## What it does
Blurs the picture. Settings: intensity, speed, fade

## Best used when
Hiding something or a dreamy memory

## Prompt to make it from scratch
A "Blur" effect over a stretch of video: Blurs the picture. Settings: intensity, speed, fade. Settings for intensity, speed and fade; the footage stays visible.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
