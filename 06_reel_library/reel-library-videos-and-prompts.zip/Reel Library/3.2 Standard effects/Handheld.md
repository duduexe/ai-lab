# Handheld

Section: 3.2 Standard effects
Video: Handheld.mp4 (4 seconds, no sound)

## What it does
The picture drifts gently like a camera held in the hand. Settings: intensity, speed, fade

## Best used when
A still shot should feel alive and filmed by hand

## Prompt to make it from scratch
A "Handheld" effect over a stretch of video: The picture drifts gently like a camera held in the hand. Settings: intensity, speed, fade. Settings for intensity, speed and fade; the footage stays visible.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
