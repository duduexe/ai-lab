# VHS

Section: 3.2 Standard effects
Video: VHS.mp4 (4 seconds, no sound)

## What it does
Lines, a rolling band, grain and a PLAY counter of an old tape. Settings: intensity, speed, fade

## Best used when
Retro, the 90s or home video jokes

## Prompt to make it from scratch
A "VHS" effect over a stretch of video: Lines, a rolling band, grain and a PLAY counter of an old tape. Settings: intensity, speed, fade. Settings for intensity, speed and fade; the footage stays visible.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
