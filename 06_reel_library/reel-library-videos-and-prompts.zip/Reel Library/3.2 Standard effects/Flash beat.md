# Flash beat

Section: 3.2 Standard effects
Video: Flash beat.mp4 (4 seconds, no sound)

## What it does
White flashes that pulse in a rhythm over the video. Settings: intensity, speed, fade. Option: the same white flash beat on one clip, picture or graphic for its whole time (Combo move "flashPulse", set on the right of a selected item)

## Best used when
Music beats or quick energy

## Prompt to make it from scratch
A "Flash beat" effect over a stretch of video: White flashes that pulse in a rhythm over the video. Settings: intensity, speed, fade. Settings for intensity, speed and fade; the footage stays visible. Option: the same white flash beat on one clip, picture or graphic for its whole time (Combo move "flashPulse", set on the right of a selected item).

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
