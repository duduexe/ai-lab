# Chromatic aberration

Section: 3.2 Standard effects
Video: Chromatic aberration.mp4 (4 seconds, no sound)

## What it does
Red and blue copies of the picture shift slightly to each side, a steady colour split that never jumps (unlike Glitch). Settings: intensity, speed, fade

## Best used when
A techy, music-video or "something is off" moment, used briefly

## Prompt to make it from scratch
A steady chromatic aberration over a stretch of video: the red channel shifts a few px to the right and the blue channel to the left (more with intensity), green stays, blended back together; a tiny zoom keeps coloured strips off the frame edges. Settings for intensity, speed and fade like the other effects; only where it is placed on the Effects layer.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
