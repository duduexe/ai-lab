# Pixelate

Section: 3.2 Standard effects
Video: Pixelate.mp4 (4 seconds, no sound)

## What it does
The picture turns into big square pixels; more intensity means bigger squares. Settings: intensity, speed, fade

## Best used when
Hiding something, a video game feel, or a quick "censored" joke

## Prompt to make it from scratch
A pixelate effect over a stretch of video: the picture becomes square blocks (about 6 to 56 px depending on intensity), each block one colour of the picture. Settings for intensity, speed and fade like the other effects; only where it is placed on the Effects layer.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
