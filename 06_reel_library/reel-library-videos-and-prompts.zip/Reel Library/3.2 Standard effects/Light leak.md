# Light leak

Section: 3.2 Standard effects
Video: Light leak.mp4 (4 seconds, no sound)

## What it does
Warm bright light drifting in from the edges, like old film. Settings: intensity, speed, fade

## Best used when
A warm, nostalgic or summer feel

## Prompt to make it from scratch
A "Light leak" effect over a stretch of video: Warm bright light drifting in from the edges, like old film. Settings: intensity, speed, fade. Settings for intensity, speed and fade; the footage stays visible.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
