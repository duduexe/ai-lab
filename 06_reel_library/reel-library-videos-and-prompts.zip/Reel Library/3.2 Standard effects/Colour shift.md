# Colour shift

Section: 3.2 Standard effects
Video: Colour shift.mp4 (4 seconds, no sound)

## What it does
The colours turn to other hues. Settings: intensity, speed, fade

## Best used when
A weird, trippy or fun moment

## Prompt to make it from scratch
A "Colour shift" effect over a stretch of video: The colours turn to other hues. Settings: intensity, speed, fade. Settings for intensity, speed and fade; the footage stays visible.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
