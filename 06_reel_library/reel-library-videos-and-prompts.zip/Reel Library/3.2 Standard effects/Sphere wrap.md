# Sphere wrap

Section: 3.2 Standard effects
Video: Sphere wrap.mp4 (4 seconds, no sound)

## What it does
The picture wraps around a slowly turning ball on the dark stage, with soft shading. Option: Cylinder wrap, wrapped around a turning tube. Settings: intensity, speed, fade (made for tall videos)

## Best used when
A playful "my world" or "spinning around" moment, rarely and briefly

## Prompt to make it from scratch
A sphere wrap over a stretch of video: the picture scrolls sideways and is bent onto a ball in the upper middle of the frame with a highlight and a darker rim, dark around it (option: a turning cylinder across the whole height). Settings for intensity, speed and fade like the other effects; only where it is placed on the Effects layer.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
