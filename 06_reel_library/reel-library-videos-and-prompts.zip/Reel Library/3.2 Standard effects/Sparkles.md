# Sparkles

Section: 3.2 Standard effects
Video: Sparkles.mp4 (4 seconds, no sound)

## What it does
Little sparkles twinkle over the picture. Settings: intensity, speed, fade

## Best used when
Something magical, new or pretty

## Prompt to make it from scratch
A "Sparkles" effect over a stretch of video: Little sparkles twinkle over the picture. Settings: intensity, speed, fade. Settings for intensity, speed and fade; the footage stays visible.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
