# Mirror

Section: 3.2 Standard effects
Video: Mirror.mp4 (4 seconds, no sound)

## What it does
The left half of the picture is reflected onto the right half, so the frame is symmetric. Option: Mirror reflection, the top half reflected onto the bottom half and fading out like water. Settings: intensity, speed, fade

## Best used when
A surreal, dreamy or "two of me" moment

## Prompt to make it from scratch
A mirror effect over a stretch of video: the left half is drawn and reflected onto the right half (option: the top half reflected onto the bottom half with a fade, like a reflection in water); no second copy of the video. Settings for intensity, speed and fade like the other effects; only where it is placed on the Effects layer.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
