# Region blur

Section: 3.2 Standard effects
Video: Region blur.mp4 (4 seconds, no sound)

## What it does
Only a chosen box is blurred (position, size and rounded corners), for private details on a screen recording. Option: Region blur band, a soft band across the frame for a tilt-shift look. Settings: intensity, speed, fade, x, y, width, height, radius

## Best used when
Hiding an email, a password or private data, or blurring a busy area

## Prompt to make it from scratch
A region blur over a stretch of video: a rounded box at x, y (middle) with width, height and corner radius blurs only what is under it (option: a soft blurred band across the frame at y with a height); the rest stays sharp. Settings for intensity, speed and fade like the other effects; only where it is placed on the Effects layer.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
