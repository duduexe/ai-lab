# Halftone dots

Section: 3.2 Standard effects
Video: Halftone dots.mp4 (4 seconds, no sound)

## What it does
The picture is rebuilt from printed dots whose size follows how dark it is, in your own colours on paper white (option: black dots; option on black: light dots on plain black, the bright parts get the big dots, for B-roll and screenshots). Settings: intensity, speed, fade, dot size, black dots, on black

## Best used when
A retro print, comic or newspaper feel for a quote or a flashback; on black for B-roll

## Prompt to make it from scratch
A halftone effect over a stretch of video: dots on a grid whose size follows the darkness of the picture, in the picture's own colours on an off-white paper (option: dark ink dots), blended with the original by intensity; dot spacing about 14 px. Settings for intensity, speed and fade like the other effects; only where it is placed on the Effects layer.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
