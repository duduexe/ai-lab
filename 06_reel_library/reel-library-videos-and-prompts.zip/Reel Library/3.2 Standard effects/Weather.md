# Weather

Section: 3.2 Standard effects
Video: Weather.mp4 (4 seconds, no sound)

## What it does
Falling rain: thin white and light streaks at different depths, slanted by the wind. Option: Weather snow, soft flakes drifting down. Settings: intensity, speed, fade

## Best used when
A mood moment: a gloomy rainy day, a cosy winter or a festive feel

## Prompt to make it from scratch
A weather overlay over a stretch of video: about 110 thin rain streaks (white and light, see-through, slanted, faster and bigger when closer), or the snow option with about 80 soft flakes drifting down with a gentle sway. Settings for intensity, speed and fade like the other effects; only where it is placed on the Effects layer.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
