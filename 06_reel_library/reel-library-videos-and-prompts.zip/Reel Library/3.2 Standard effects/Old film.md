# Old film

Section: 3.2 Standard effects
Video: Old film.mp4 (4 seconds, no sound)

## What it does
Grain, scratches and dark corners of old film. Settings: intensity, speed, fade

## Best used when
Memories or "back in the day"

## Prompt to make it from scratch
A "Old film" effect over a stretch of video: Grain, scratches and dark corners of old film. Settings: intensity, speed, fade. Settings for intensity, speed and fade; the footage stays visible.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
