# Lens distortion

Section: 3.2 Standard effects
Video: Lens distortion.mp4 (4 seconds, no sound)

## What it does
A fisheye bulge from the middle of the frame (or a pinch with the pinch option); at low values your face stays natural. Settings: intensity, speed, fade, pinch

## Best used when
A funny close look, a "wide lens" vlog feel, or a surprise reaction

## Prompt to make it from scratch
A lens distortion over a stretch of video: a radial displacement map bulges the middle like a fisheye (pinch option pulls it in instead); keep it gentle at low intensity so the face stays natural. Settings for intensity, speed and fade like the other effects; only where it is placed on the Effects layer.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
