# Vignette

Section: 3.2 Standard effects
Video: Vignette.mp4 (4 seconds, no sound)

## What it does
Darker corners that pull the eye to the middle. Settings: intensity, speed, fade

## Best used when
Focusing on you and calming the edges

## Prompt to make it from scratch
A "Vignette" effect over a stretch of video: Darker corners that pull the eye to the middle. Settings: intensity, speed, fade. Settings for intensity, speed and fade; the footage stays visible.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
