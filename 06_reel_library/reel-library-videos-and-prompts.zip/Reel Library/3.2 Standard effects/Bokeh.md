# Bokeh

Section: 3.2 Standard effects
Video: Bokeh.mp4 (4 seconds, no sound)

## What it does
Soft round blurred lights float over the picture. Settings: intensity, speed, fade

## Best used when
A soft, festive or night mood

## Prompt to make it from scratch
A "Bokeh" effect over a stretch of video: Soft round blurred lights float over the picture. Settings: intensity, speed, fade. Settings for intensity, speed and fade; the footage stays visible.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
