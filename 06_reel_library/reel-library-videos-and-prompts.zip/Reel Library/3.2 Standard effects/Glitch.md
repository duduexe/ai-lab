# Glitch

Section: 3.2 Standard effects
Video: Glitch.mp4 (4 seconds, no sound)

## What it does
Short bursts of coloured glitch bars. Settings: intensity, speed, fade. Option: short glitch hiccups on one clip, picture or graphic now and then for its whole time (Combo move "glitchBursts", old name Glitch bursts)

## Best used when
Tech problems or a fast cut between ideas

## Prompt to make it from scratch
A "Glitch" effect over a stretch of video: Short bursts of coloured glitch bars. Settings: intensity, speed, fade. Settings for intensity, speed and fade; the footage stays visible. Option: short glitch hiccups on one clip, picture or graphic now and then for its whole time (Combo move "glitchBursts", old name Glitch bursts).

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
