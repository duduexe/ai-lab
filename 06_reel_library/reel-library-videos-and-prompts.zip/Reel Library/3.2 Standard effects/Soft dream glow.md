# Soft dream glow

Section: 3.2 Standard effects
Video: Soft dream glow.mp4 (4 seconds, no sound)

## What it does
A soft, bright, blurred glow over the picture. Settings: intensity, speed, fade

## Best used when
A soft, romantic or dreamy moment

## Prompt to make it from scratch
A "Soft dream glow" effect over a stretch of video: A soft, bright, blurred glow over the picture. Settings: intensity, speed, fade. Settings for intensity, speed and fade; the footage stays visible.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
