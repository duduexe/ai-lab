# Shake

Section: 3.2 Standard effects
Video: Shake.mp4 (4 seconds, no sound)

## What it does
The picture shakes, like an impact. Settings: intensity, speed, fade. Option: the same shake on one clip, picture or graphic for its whole time (Combo move "shake")

## Best used when
An impact, a shock or a bass drop

## Prompt to make it from scratch
A "Shake" effect over a stretch of video: The picture shakes, like an impact. Settings: intensity, speed, fade. Settings for intensity, speed and fade; the footage stays visible. Option: the same shake on one clip, picture or graphic for its whole time (Combo move "shake").

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
