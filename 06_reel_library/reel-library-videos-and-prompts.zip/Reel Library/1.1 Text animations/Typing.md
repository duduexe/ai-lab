# Typing

Section: 1.1 Text animations
Video: Typing.mp4 (4 seconds, no sound)

## What it does
Typed in like on a keyboard

## Best used when
You show something typed: a prompt, a search, a message

## Prompt to make it from scratch
Animate a text box on a 1080 x 1920 reel (how it arrives): Typed in like on a keyboard. Quick (about 0.35 s), smooth, the text stays readable and keeps its own font and colour.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
