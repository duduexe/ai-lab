# Fade reveal

Section: 1.1 Text animations
Video: Fade reveal.mp4 (4 seconds, no sound)

## What it does
Letters fade in one by one

## Best used when
A calm title or quote that builds letter by letter

## Prompt to make it from scratch
Animate a text box on a 1080 x 1920 reel (how it arrives): Letters fade in one by one. Quick (about 0.35 s), smooth, the text stays readable and keeps its own font and colour.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
