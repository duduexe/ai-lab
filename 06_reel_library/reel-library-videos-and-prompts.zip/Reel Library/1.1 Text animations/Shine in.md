# Shine in

Section: 1.1 Text animations
Video: Shine in.mp4 (4 seconds, no sound)

## What it does
A light sweeps across the letters

## Best used when
A premium or "new" word that deserves a little shine

## Prompt to make it from scratch
Animate a text box on a 1080 x 1920 reel (how it arrives): A light sweeps across the letters. Quick (about 0.35 s), smooth, the text stays readable and keeps its own font and colour.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
