# Text fill

Section: 1.1 Text animations
Video: Text fill.mp4 (4 seconds, no sound)

## What it does
The text fills with colour

## Best used when
A progress feel: a word that fills up as you speak

## Prompt to make it from scratch
Animate a text box on a 1080 x 1920 reel (how it arrives): The text fills with colour. Quick (about 0.35 s), smooth, the text stays readable and keeps its own font and colour.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
