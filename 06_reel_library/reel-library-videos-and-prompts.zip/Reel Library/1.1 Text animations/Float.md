# Float

Section: 1.1 Text animations
Video: Float.mp4 (4 seconds, no sound)

## What it does
Floats up and down

## Best used when
A light, calm text stays a while

## Prompt to make it from scratch
Animate a text box on a 1080 x 1920 reel (how it moves while it stays): Floats up and down. Quick (about 0.35 s), smooth, the text stays readable and keeps its own font and colour.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
