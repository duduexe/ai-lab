# Balloon inflate in

Section: 1.1 Text animations
Video: Balloon inflate in.mp4 (4 seconds, no sound)

## What it does
The text box fills up like a balloon: it starts as a tiny round blob, grows in three puffs of air from its bottom middle, stretches like rubber, gets a soft white shine, goes a little too big and wobbles into place with its own corners back

## Best used when
A playful word or line in a box should grow and land with fun, for example "and so much more" or a reveal

## Prompt to make it from scratch
Animate a text box on a 1080 x 1920 reel (how it arrives) like a balloon being blown up: the box starts as a tiny round blob at about 6% size, fills from its bottom middle in three quick puffs (about 40%, 70%, then 110%, with a small breath between puffs), stretches taller and wider like rubber while it fills, sways a few degrees, is fully round while small and gets its own corner radius back once full, shows a soft white shine at its top left, then settles to 100% with a short jelly wobble. About 1.1 s in total. Keeps its own font, colours and box; stays inside the safe zone.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
