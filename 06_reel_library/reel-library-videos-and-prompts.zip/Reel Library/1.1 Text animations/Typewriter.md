# Typewriter

Section: 1.1 Text animations
Video: Typewriter.mp4 (4 seconds, no sound)

## What it does
Letters appear one after another

## Best used when
The text is a thought, a prompt or a quote you want read letter by letter

## Prompt to make it from scratch
Animate a text box on a 1080 x 1920 reel (how it arrives): Letters appear one after another. Quick (about 0.35 s), smooth, the text stays readable and keeps its own font and colour.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
