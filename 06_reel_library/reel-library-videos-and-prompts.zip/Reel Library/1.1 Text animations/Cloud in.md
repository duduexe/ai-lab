# Cloud in

Section: 1.1 Text animations
Video: Cloud in.mp4 (4 seconds, no sound)

## What it does
A blurred puff of white mist condenses into each letter

## Best used when
A dreamy, soft or magical moment

## Prompt to make it from scratch
Animate a text box on a 1080 x 1920 reel (how it arrives): A blurred puff of white mist condenses into each letter. Quick (about 0.35 s), smooth, the text stays readable and keeps its own font and colour.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
