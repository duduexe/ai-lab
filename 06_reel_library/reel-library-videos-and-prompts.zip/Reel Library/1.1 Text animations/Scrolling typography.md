# Scrolling typography

Section: 1.1 Text animations
Video: Scrolling typography.mp4 (4 seconds, no sound)

## What it does
The text block rises from below the frame, tilted back, and shrinks toward a vanishing point at the top where it fades, like an opening crawl; it keeps moving for the whole text item

## Best used when
Credits, a long list or a story intro you scroll through

## Prompt to make it from scratch
Animate a text block on a 1080 x 1920 reel like an opening crawl: it starts below the frame, tilted back about 22 degrees with perspective, rises through the whole item and shrinks toward a vanishing point near the top, fading in at the start and out at the end; the item length sets the speed.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
