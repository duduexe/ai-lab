# Cloud loop

Section: 1.1 Text animations
Video: Cloud loop.mp4 (4 seconds, no sound)

## What it does
A gentle wave and float with a soft white glow

## Best used when
A dreamy title stays on screen

## Prompt to make it from scratch
Animate a text box on a 1080 x 1920 reel (how it moves while it stays): A gentle wave and float with a soft white glow. Quick (about 0.35 s), smooth, the text stays readable and keeps its own font and colour.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
