# Wave loop

Section: 1.1 Text animations
Video: Wave loop.mp4 (4 seconds, no sound)

## What it does
Letters ripple

## Best used when
A word stays on screen a while and should keep a bit of life

## Prompt to make it from scratch
Animate a text box on a 1080 x 1920 reel (how it moves while it stays): Letters ripple. Quick (about 0.35 s), smooth, the text stays readable and keeps its own font and colour.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
