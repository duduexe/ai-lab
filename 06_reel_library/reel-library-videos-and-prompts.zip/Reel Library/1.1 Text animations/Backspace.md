# Backspace

Section: 1.1 Text animations
Video: Backspace.mp4 (4 seconds, no sound)

## What it does
Letters are deleted one by one, like backspace

## Best used when
You "take back" a word or show you changed your mind

## Prompt to make it from scratch
Animate a text box on a 1080 x 1920 reel (how it leaves): Letters are deleted one by one, like backspace. Quick (about 0.35 s), smooth, the text stays readable and keeps its own font and colour.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
