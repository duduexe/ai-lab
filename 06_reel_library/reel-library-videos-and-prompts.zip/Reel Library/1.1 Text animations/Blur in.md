# Blur in

Section: 1.1 Text animations
Video: Blur in.mp4 (4 seconds, no sound)

## What it does
Starts blurred and sharpens

## Best used when
A soft, premium entrance for a title

## Prompt to make it from scratch
Animate a text box on a 1080 x 1920 reel (how it arrives): Starts blurred and sharpens. Quick (about 0.35 s), smooth, the text stays readable and keeps its own font and colour.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
