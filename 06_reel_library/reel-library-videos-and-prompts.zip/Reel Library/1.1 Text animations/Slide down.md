# Slide down

Section: 1.1 Text animations
Video: Slide down.mp4 (4 seconds, no sound)

## What it does
Slides down

## Best used when
The text goes away as the next line comes in from above

## Prompt to make it from scratch
Animate a text box on a 1080 x 1920 reel (how it leaves): Slides down. Quick (about 0.35 s), smooth, the text stays readable and keeps its own font and colour.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
