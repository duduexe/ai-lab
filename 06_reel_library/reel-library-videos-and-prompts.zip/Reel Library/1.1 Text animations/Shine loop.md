# Shine loop

Section: 1.1 Text animations
Video: Shine loop.mp4 (4 seconds, no sound)

## What it does
A light sweeps across

## Best used when
A brand or "new" word stays on screen

## Prompt to make it from scratch
Animate a text box on a 1080 x 1920 reel (how it moves while it stays): A light sweeps across. Quick (about 0.35 s), smooth, the text stays readable and keeps its own font and colour.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
