# Pop in

Section: 1.1 Text animations
Video: Pop in.mp4 (4 seconds, no sound)

## What it does
Jumps in with a small bounce

## Best used when
A word or label should feel lively and land on a beat

## Prompt to make it from scratch
Animate a text box on a 1080 x 1920 reel (how it arrives): Jumps in with a small bounce. Quick (about 0.35 s), smooth, the text stays readable and keeps its own font and colour.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
