# Cloud out

Section: 1.1 Text animations
Video: Cloud out.mp4 (4 seconds, no sound)

## What it does
Letters turn back into mist, drift up and fade

## Best used when
A dreamy word drifts away

## Prompt to make it from scratch
Animate a text box on a 1080 x 1920 reel (how it leaves): Letters turn back into mist, drift up and fade. Quick (about 0.35 s), smooth, the text stays readable and keeps its own font and colour.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
