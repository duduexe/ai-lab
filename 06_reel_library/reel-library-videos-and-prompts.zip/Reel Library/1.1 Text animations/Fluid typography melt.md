# Fluid typography melt

Section: 1.1 Text animations
Video: Fluid typography melt.mp4 (4 seconds, no sound)

## What it does
Each letter stretches down from its top and drips away at its own speed, then fades

## Best used when
A playful exit: something melts, is too hot, or falls apart

## Prompt to make it from scratch
Animate a text exit: letter by letter, each letter stretches down from its top (up to about 3 times its height), slides down and blurs a little at its own random speed like a drip, then fades.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
