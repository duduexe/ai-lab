# Wave in

Section: 1.1 Text animations
Video: Wave in.mp4 (4 seconds, no sound)

## What it does
Letters rise in as a wave

## Best used when
A friendly title with movement, for a light topic

## Prompt to make it from scratch
Animate a text box on a 1080 x 1920 reel (how it arrives): Letters rise in as a wave. Quick (about 0.35 s), smooth, the text stays readable and keeps its own font and colour.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
