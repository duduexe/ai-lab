# Zoom in

Section: 3.3 Zoom
Video: Zoom in.mp4 (4 seconds, no sound)

## What it does
Slowly moves closer to your face. A slow zoom over a long talking-head part is this same zoom. Option: a slow zoom in on one clip, picture or graphic for its whole time (Combo move "slowZoom")

## Best used when
Building tension or getting closer to an important point

## Prompt to make it from scratch
A zoom on the footage: Slowly moves closer to your face. Centred on the face, smooth, on its own zoom layer. A slow zoom over a long talking-head part is this same zoom. Option: a slow zoom in on one clip, picture or graphic for its whole time (Combo move "slowZoom").

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
