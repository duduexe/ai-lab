# Zoom out

Section: 3.3 Zoom
Video: Zoom out.mp4 (4 seconds, no sound)

## What it does
Starts close and slowly pulls back

## Best used when
Opening up, a calm ending or showing more

## Prompt to make it from scratch
A zoom on the footage: Starts close and slowly pulls back. Centred on the face, smooth, on its own zoom layer.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
