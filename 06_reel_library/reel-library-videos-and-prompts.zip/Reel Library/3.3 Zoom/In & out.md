# In & out

Section: 3.3 Zoom
Video: In & out.mp4 (4 seconds, no sound)

## What it does
Moves closer, then back out

## Best used when
A breathing feel over a longer talk

## Prompt to make it from scratch
A zoom on the footage: Moves closer, then back out. Centred on the face, smooth, on its own zoom layer.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
