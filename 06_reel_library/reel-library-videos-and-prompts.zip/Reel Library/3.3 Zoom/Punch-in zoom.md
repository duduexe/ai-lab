# Punch-in zoom

Section: 3.3 Zoom
Video: Punch-in zoom.mp4 (4 seconds, no sound)

## What it does
Quick zoom on your face to stress a word, scale 1 to 2, hard cut or quick glide. Option: quick punch-ins that follow the face track

## Best used when
Stressing one word or a punchline

## Prompt to make it from scratch
A zoom on the footage: Quick zoom on your face to stress a word, scale 1 to 2, hard cut or quick glide. Centred on the face, smooth, on its own zoom layer. Option: quick punch-ins that follow the face track.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
