# Angled Screen

Section: 4.4 Apps, windows and screens
Video: Angled Screen.mp4 (4 seconds, no sound)

## What it does
A screen recording or screenshot on a tilted, see-through panel next to you. Option: angle 0 lies the panel flat and zooms on one part of the screen (zoom, focusX, focusY)

## Best used when
Showing a screen recording next to you

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A screen recording or screenshot on a tilted, see-through panel next to you. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons). Option: angle 0 lies the panel flat and zooms on one part of the screen (zoom, focusX, focusY).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
