# Glass App Bar

Section: 4.4 Apps, windows and screens
Video: Glass App Bar.mp4 (4 seconds, no sound)

## What it does
A frosted glass bar slides up with four simple icons; a glass bubble hops from icon to icon and the active icon turns bright.

## Best used when
Switching between apps or features

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: a frosted glass bar slides up with four simple icons; a glass bubble hops from icon to icon and the active icon turns bright. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
