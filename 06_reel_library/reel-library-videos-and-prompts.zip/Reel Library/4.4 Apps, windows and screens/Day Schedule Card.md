# Day Schedule Card

Section: 4.4 Apps, windows and screens
Video: Day Schedule Card.mp4 (4 seconds, no sound)

## What it does
A dark phone card slides in showing a week strip and a day view with hour rows; one event block pops in on its hour, then a bright hand-drawn circle draws itself round it like a pen

## Best used when
Saying when something happens, a plan for one day or a booked slot

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: dark phone card 400 px wide and 690 px tall (rounded, tilted -3 degrees, soft shadow), top left at x 70, y 620 (safe zone, clear of the app buttons); slides in from the right with a bounce in 0.55 s; top: week strip (letters M to S, dates, the chosen day in a bright circle), then the day name, then hour rows 08:00 to 12:00 (a small pixel-style label font) that fade in one by one; at 0.55 s a coloured event block with a bright left bar pops in on the 09:00 row (title in a clean sans font bold, time line under it, dark text); at 1.5 s a bright hand-drawn circle (9 px, a bit uneven, goes round more than once) draws itself round the block in 0.55 s; floats gently; fades out in the last 0.35 s.

## Source
Inspired by a public social media reel, our own version made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
