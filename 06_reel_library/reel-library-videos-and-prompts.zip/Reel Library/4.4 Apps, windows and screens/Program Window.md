# Program Window

Section: 4.4 Apps, windows and screens
Video: Program Window.mp4 (4 seconds, no sound)

## What it does
A program window, like a computer app, showing a screenshot of what the AI made, with a loading bar that fills

## Best used when
Showing what an AI or a tool made

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A program window, like a computer app, showing a screenshot of what the AI made, with a loading bar that fills. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
