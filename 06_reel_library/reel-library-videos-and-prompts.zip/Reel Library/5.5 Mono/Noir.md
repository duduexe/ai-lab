# Noir

Section: 5.5 Mono
Video: Noir.mp4 (4 seconds, no sound)

## What it does
Black and white, punchy contrast, film grain, dark edges

## Best used when
A mysterious or dramatic moment

## Prompt to make it from scratch
A colour filter for talking-head footage: black and white, punchy contrast, film grain, dark edges. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
