# Black & White

Section: 5.5 Mono
Video: Black & White.mp4 (4 seconds, no sound)

## What it does
Black and white, punchy contrast. Also a video effect for a short stretch, the same look

## Best used when
Flashbacks or serious moments

## Prompt to make it from scratch
A colour filter for talking-head footage: black and white, punchy contrast. Skin stays natural, with an intensity slider, only where it is placed. Also a video effect for a short stretch, the same look.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
