# Silver Print

Section: 5.5 Mono
Video: Silver Print.mp4 (4 seconds, no sound)

## What it does
Black and white, faded blacks

## Best used when
A soft, elegant black and white

## Prompt to make it from scratch
A colour filter for talking-head footage: black and white, faded blacks. Skin stays natural, with an intensity slider, only where it is placed.

## Source
Standard video montage

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
