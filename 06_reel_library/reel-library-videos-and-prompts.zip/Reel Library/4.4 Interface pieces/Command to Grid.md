# Command to Grid

Section: 4.4 Interface pieces
Video: Command to Grid.mp4 (4 seconds, no sound)

## What it does
A dark terminal types a command, the answer line comes in with a bright tick, then the terminal moves up and a grid of named thumbnails pops in tile by tile, for example "my animation library in one video" (props command, result, names split by /, images, columns, typeAt, resultAt, gridAt)

## Best used when
Showing what one command gives you: a whole library, a set of results, many outputs at once

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: a dark terminal window types a command ("/animation-library") from 0.3 s; at 1.5 s an answer line ("120 animations found in 8 styles") comes in with a bright tick; at 2.3 s the terminal slides up and a grid of 3 columns of rounded thumbnails (pictures or short clips, or a coloured tile when missing), each with its name under it, pops in tile by tile; stays inside the safe zone; fades out at the end.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
