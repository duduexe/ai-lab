# Phone Messages

Section: 4.4 Interface pieces
Video: Phone Messages.mp4 (4 seconds, no sound)

## What it does
A simple phone with chat bubbles and typing dots

## Best used when
A chat or text conversation

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A simple phone with chat bubbles and typing dots. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons). with chat bubbles and typing dots.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
