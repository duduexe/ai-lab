# Loading Screen

Section: 4.4 Interface pieces
Video: Loading Screen.mp4 (4 seconds, no sound)

## What it does
A loading window that counts to 100 like a real one (quick start, a short stall, then the rest), then says Ready with a tick. Three styles: blocks (ten squares fill one by one), ring (squares light up round the number) or tube (a tube fills with coloured behind a spinning sparkle). Options: style (blocks, ring, tube), title, speed

## Best used when
Something is being made or the AI is working, and you want a short wait before the result

## Prompt to make it from scratch
A motion graphic made with code for a 1080 x 1920 reel: a flat sticker window (bright title bar with three small squares and the word LOADING in a pixel font, white body, 4 px dark outline, hard dark shadow with no blur). Inside: a big chunky dark number that counts from 0 to 100 with a percent sign, below it a row of ten outlined squares that fill bright one by one with a small pop (the newest one bright), and below that the word LOADING in a pixel font with three small squares that blink in turn. The count starts fast, stalls for a moment near 66, then finishes. At 100 the squares hop in a wave, the word becomes READY, the window shadow turns bright and a round bright sticker with a tick pops onto the top right corner. Other styles: twelve squares in a ring around the number, or a pill-shaped tube that fills with coloured behind a spinning bright four-point sparkle. light background.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
