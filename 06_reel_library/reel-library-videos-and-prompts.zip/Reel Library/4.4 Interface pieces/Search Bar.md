# Search Bar

Section: 4.4 Interface pieces
Video: Search Bar.mp4 (4 seconds, no sound)

## What it does
Search query types in, then the search button is pressed

## Best used when
Showing a search

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: Search query types in, then the search button is pressed. Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
