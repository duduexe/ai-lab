# Button Cover

Section: 4.4 Interface pieces
Video: Button Cover.mp4 (4 seconds, no sound)

## What it does
Fixes a button that is cut off or messy in a screen recording: a plain patch in the page colour hides the original, and a clean drawn button pops in next to it, whole and inside the safe zone. At the click it presses, a bright tick draws itself, the label changes (for example Copy to Copied) and a few bright sparks fly

## Best used when
A button you press in a screen recording is cut off at the edge or sits under the app buttons

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over a screen recording: a rectangle in the page colour covers a cut-off button at the right edge; a rounded dark button with a coloured edge and a copy icon pops in (0.3 s) next to it, fully visible; at the click time it presses down, a bright tick draws itself and the label changes to the done word, with a few bright sparks; it fades in the last 0.15 s. Stays inside the safe zone (left of x 887 below y 860), plain sans font for the button label.

## Source
Made by Claude with code for "Reel Library phone", no licence needed

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
