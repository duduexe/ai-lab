# Inset Clip

Section: 4.4 Interface pieces
Video: Inset Clip.mp4 (4 seconds, no sound)

## What it does
A second clip or picture in a rounded, pale frame on top of your video (picture in picture)

## Best used when
A second clip or picture next to you

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: A second clip or picture in a rounded, pale frame on top of your video (picture in picture). Pops in (about 0.4 s) and fades out (0.3 s), stays inside the safe zone (away from the app buttons).

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
