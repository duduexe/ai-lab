# Retro Pop-up

Section: 4.4 Interface pieces
Video: Retro Pop-up.mp4 (4 seconds, no sound)

## What it does
Retro computer props in one.exe look (bright title bar with a square close button, dark edge, coloured hard shadow). Kind notepad: a little text file whose lines type in one after the other. Kind error: an error box shakes in, a cursor glides to OK and clicks it, then the box closes (props kind, title, text with lines split by /, button, clickAt, -1 = no click; x, y, width)

## Best used when
A thought written down as a note, or a mistake and its fix told as a computer error

## Prompt to make it from scratch
A graphic animation made with code for a 1080 x 1920 reel that works over any video: a retro program window 780 px wide, centred at x 540, y 720, with a bright title bar (title "notes.txt" or "error.exe"), a square close button, a dark edge and a hard coloured shadow. Notepad: lines of text type in one after the other in a mono font. Error: the box shakes in with a warning icon and a message, a cursor glides to the OK button and clicks it at 1.8 s, the button presses and the box closes. Stays inside the safe zone.

## Source
Original, made with code

© 2026 Dudu.exe. Compiled and made by Dudu.exe. All rights reserved.
